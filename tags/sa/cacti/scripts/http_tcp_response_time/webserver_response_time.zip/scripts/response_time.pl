#!/usr/bin/perl
#

use LWP::UserAgent;
use Time::HiRes qw ( gettimeofday tv_interval);

my $host = $ARGV[0];
chomp $host;
my $port = $ARGV[1];
chomp $port;
my $uri = $ARGV[2];
chomp $uri;

$URL ="http://$host:$port/$uri";

$ua = new LWP::UserAgent;
$ua->agent('Cacti Web Response Time Script');  
$t0 = [gettimeofday];
$req = new HTTP::Request GET => $URL;
$foo = $ua->request($req);
$response = $$foo{_content};
$t1 = [gettimeofday];
$elapsed = tv_interval($t0,$t1);

if ($foo->is_success) {
        print "$elapsed";
} else {
        print "0";
}