<?php


include("./include/auth.php");


$pluginslist = retrieve_plugin_list ();

/* tab information */
$ptabs = array(
	"current" => "Installed",
//	"uninstalled" => "Uninstalled",
//	"download" => "Download",
//	"updates" => "Updates",
);


$status_names = array(-2 => 'Old Plugin Architecture', -1 => 'Old Plugin Architecture - Running', 0 => 'Not Installed', 1 => 'Active', 2 => 'Awaiting Configuration', 3 => 'Awaiting Upgrade', 4 => 'Installed');


/* set the default settings category */
if (!isset($_GET["tab"])) {
	/* there is no selected tab; select the first one */
	$current_tab = array_keys($ptabs);
	$current_tab = $current_tab[0];
}else{
	$current_tab = $_GET["tab"];
}


// Check to see if we are installing, etc...
$modes = array('install', 'uninstall', 'disable', 'enable', 'check');

if (isset($_GET['mode']) && in_array($_GET['mode'], $modes)  && isset($_GET['id'])) {

	input_validate_input_regex(get_request_var("id"), "^([a-zA-Z0-9]+)$");

	$mode = $_GET['mode'];
	$id = sanitize_search_string($_GET['id']);

	switch ($mode) {
		case 'install':
			api_plugin_install($id);
			$pluginslist = retrieve_plugin_list ();
			break;
		case 'uninstall':
			if (!in_array($id, $pluginslist))
				break;
			api_plugin_uninstall($id);
			$pluginslist = retrieve_plugin_list ();
			break;
		case 'disable':
			if (!in_array($id, $pluginslist))
				break;
			api_plugin_disable ($id);
			break;
		case 'enable':
			if (!in_array($id, $pluginslist))
				break;
			api_plugin_enable ($id);
			break;
		case 'check':
			if (!in_array($id, $pluginslist))
				break;
			break;
	}
}

function retrieve_plugin_list () {
	$pluginslist = array();
	$temp = db_fetch_assoc('SELECT directory FROM plugin_config ORDER BY name');
	foreach ($temp as $t) {
		$pluginslist[] = $t['directory'];
	}
	return $pluginslist;
}


	include("./include/top_header.php");

	/* draw the categories tabs on the top of the page */
/*
	print "<table class='tabs' width='98%' cellspacing='0' cellpadding='3' align='center'><tr>\n";

	if (sizeof($ptabs) > 0) {
		foreach (array_keys($ptabs) as $tab_short_name) {
			print "<td " . (($tab_short_name == $current_tab) ? "bgcolor='silver'" : "bgcolor='#DFDFDF'") . " nowrap='nowrap' width='" . (strlen($ptabs[$tab_short_name]) * 9) . "' align='center' class='tab'>
				<span class='textHeader'><a href='plugins.php?tab=$tab_short_name'>$ptabs[$tab_short_name]</a></span>
				</td>\n
				<td width='1'></td>\n";
		}
	}

	print "<td></td>\n</tr></table>\n";
*/
	html_start_box("<strong> Plugin Management</strong>", "98%", $colors["header"], "3", "center", "");

	print "<tr><td><table width='100%'>";

	//update_info_table();

	switch ($current_tab) {
		case 'current':
			update_show_current();
			break;
		case 'uninstalled':
			update_show_uninstalled ();
			break;
		default:
			print '<br><br><br>';
	}

/*
	$last_check = read_config_option("plugin_update_last_check");
	if ($last_check < 1)
		$last_check = 0;

	print "<center>Last Scanned : " . ($last_check > 0 ? date("F j, Y g:i:s a", $last_check) : "Never") . "</center>";
*/
	print "</table></td></tr>";

	html_end_box();

	include("./include/bottom_footer.php");

function update_show_updates () {
	global $pluginslist, $colors, $config, $plugin_architecture;

	$cinfo = array();
	sort($pluginslist);

	$cinfo = update_get_plugin_info ();

	$x = 0;

	$info = update_get_cached_plugin_info();

	$cactinew = update_check_if_newer($cinfo['cacti']['version'], $info['cacti']['version']) ;
	if (isset($cinfo['cacti_plugin_arch']['version']))
		$archnew =  update_check_if_newer($cinfo['cacti_plugin_arch']['version'], $info['cacti_plugin_arch']['version']);
	else
		$archnew = 0;

	if ($cactinew) {
		$x++;
		print "<tr><td width='25%' valign=top><table width='100%'>";
		html_header(array("Cacti"), 2);
		form_alternate_row_color($colors["alternate"],$colors["light"], 0);
		print "<td width='25%'><strong>Version:</strong></td><td>" . $config["cacti_version"] . "</td></tr>";
		form_alternate_row_color($colors["alternate"],$colors["light"], 0);
		print "<td valign=top><strong>Changes:</strong></td><td>" . str_replace("\n", '<br>', $info['cacti']['changes']) . "</td></tr></table>";
	}
	if (isset($plugin_architecture['version']) && $archnew) {
		$x++;
		print "<table width='100%'>";
		html_header(array("Plugin Architecture"), 2);
		form_alternate_row_color($colors["alternate"],$colors["light"], 0);
		print "<td width='25%'><strong>Version:</strong></td><td>" . $plugin_architecture['version'] . "</td>";
		form_alternate_row_color($colors["alternate"],$colors["light"], 0);
		print "<td valign=top><strong>Changes:</strong></td><td>" . str_replace("\n", '<br>', $info['cacti_plugin_arch']['changes']) . "</td></tr></table>";
	}
	print "<table width='100%' cellspacing=0 cellpadding=3>";

	foreach ($pluginslist as $plugin) {
		if (isset($cinfo[$plugin]) && update_check_if_newer($cinfo[$plugin]['version'], $info[$plugin]['version'])) {
			$x++;
			print "<table width='100%'>";
			html_header(array((isset($cinfo[$plugin]['longname']) ? $cinfo[$plugin]['longname'] : $plugin)), 2);
			form_alternate_row_color($colors["alternate"],$colors["light"], 0);
			print "<td width='50%'><strong>Directory:</strong></td><td>$plugin</td>";
			form_alternate_row_color($colors["alternate"],$colors["light"], 0);
			print "<td><strong>Version:</strong></td><td>" . $info[$plugin]['version'] . "</td>";
			form_alternate_row_color($colors["alternate"],$colors["light"], 0);
			print "<td><strong>Author:</strong></td><td>" . (isset($cinfo[$plugin]['author']) && $cinfo[$plugin]['author'] != '' ? (isset($cinfo[$plugin]['email']) && $cinfo[$plugin]['email'] != '' ? "<a href='mailto:" . $cinfo[$plugin]['email'] . "'>" . $cinfo[$plugin]['author'] . "</a>"  : $cinfo[$plugin]['author']) : "") . "</td>";
			form_alternate_row_color($colors["alternate"],$colors["light"], 0);
			print "<td><strong>Home Page:</strong></td><td>" . (isset($cinfo[$plugin]['webpage']) && $cinfo[$plugin]['webpage'] != '' ? "<a href='" . $cinfo[$plugin]['webpage'] . "'>" . $cinfo[$plugin]['webpage'] . "</a>" : "") . "</td>";
			form_alternate_row_color($colors["alternate"],$colors["light"], 0);
			print "<td valign=top><strong>Changes:</strong></td><td>" . str_replace("\n", '<br>', $info[$plugin]['changes']) . "</td>";

			print "</tr></table>";
		}
	}
	if ($x == 0)
		print "<br><center><b>There are currently no Updates!</b></center><br>";
	print "</table>";
	html_end_box(TRUE);
}

function update_check_if_newer() {
	return false;
}

function update_show_current () {
	global $plugins, $pluginslist, $colors, $plugin_architecture, $config, $status_names;



	$cinfo = array();
	$cinfo = update_get_plugin_info ();

	sort($pluginslist);

	$path = $config['base_path'] . '/plugins/';
	$dh = opendir($path);
	while (($file = readdir($dh)) !== false) {
		if (is_dir("$path/$file")) {
			if (file_exists("$path/$file/setup.php") && !in_array($file, $pluginslist)) {
				include_once("$path/$file/setup.php");
				if (!function_exists('plugin_' . $file . '_install') && function_exists($file . '_version')) {
					$function = $file . '_version';
					$cinfo[$file] = $function();
					$cinfo[$file]['status'] = -2;
					if (in_array($file, $plugins)) {
						$cinfo[$file]['status'] = -1;
					}
					$pluginslist[] = $file;
				} else if (function_exists('plugin_' . $file . '_install') && function_exists('plugin_' . $file . '_version')) {
					$function = $file . '_version';
					$cinfo[$file] = $function();
					$cinfo[$file]['status'] = 0;
					$pluginslist[] = $file;
				}
			}
		}
	}
	closedir($dh);

	print "<table width='100%' cellspacing=0 cellpadding=3>";
	print "<tr><td width='50%'><table width='100%'>";
	html_header(array("Cacti"), 2);
	form_alternate_row_color($colors["alternate"],$colors["light"], 0);
	print "<td width='50%'><strong>Version:</strong></td><td>" . $config["cacti_version"] . "</td></tr></table>";
	print "</td><td>";
	if (isset($plugin_architecture['version'])) {
		print "<table width='100%'>";
		html_header(array("Plugin Architecture"), 2);
		form_alternate_row_color($colors["alternate"],$colors["light"], 0);
		print "<td width='50%'><strong>Version:</strong></td><td>" . $plugin_architecture['version'] .  "</td></tr></table>";
	}
	print "</td></tr></table>";

	print "<table width='100%' cellspacing=0 cellpadding=3>";
	$x = 0;

	sort($pluginslist);
	foreach ($pluginslist as $plugin) {
		if (isset($cinfo[$plugin])) {

			if ($x == 0) {
				print "<tr><td width='50%' valign=top>";
			} else {
				print "</td><td valign=top>";
			}
			if (!isset($info[$plugin]['version']))
				$info[$plugin]['version'] = '';

			print "<table width='100%'>";
			html_header(array((isset($cinfo[$plugin]['name']) ? $cinfo[$plugin]['name'] : $plugin)), 2);
			form_alternate_row_color($colors["alternate"],$colors["light"], 0);
			print "<td width='50%'><strong>Directory:</strong></td><td>$plugin</td>";
			form_alternate_row_color($colors["alternate"],$colors["light"], 0);
			print "<td><strong>Version:</strong></td><td>" . (isset($cinfo[$plugin]['version']) ? $cinfo[$plugin]['version'] : "") . (update_check_if_newer($cinfo[$plugin]['version'], $info[$plugin]['version']) ?  ' - <font color=red><b>(Update Available!)</strong></font>' : '') . "</td>";
			form_alternate_row_color($colors["alternate"],$colors["light"], 0);
			print "<td><strong>Author:</strong></td><td>" . (isset($cinfo[$plugin]['author']) && $cinfo[$plugin]['author'] != '' ? (isset($cinfo[$plugin]['email']) && $cinfo[$plugin]['email'] != '' ? "<a href='mailto:" . $cinfo[$plugin]['email'] . "'>" . $cinfo[$plugin]['author'] . "</a>"  : $cinfo[$plugin]['author']) : "") . "</td>";
			form_alternate_row_color($colors["alternate"],$colors["light"], 0);
			print "<td><strong>Home Page:</strong></td><td>" . (isset($cinfo[$plugin]['webpage']) && $cinfo[$plugin]['webpage'] != '' ? "<a href='" . $cinfo[$plugin]['webpage'] . "'>" . $cinfo[$plugin]['webpage'] . "</a>" : "") . "</td>";
			form_alternate_row_color($colors["alternate"],$colors["light"], 0);
			print "<td><strong>Status:</strong></td><td>" . $status_names[$cinfo[$plugin]['status']] . "</td>";

			if ($cinfo[$plugin]['status'] > -1) {
				form_alternate_row_color($colors["alternate"],$colors["light"], 0);

				$links = array('install' => 'Install', 'uninstall' => 'Uninstall', 'enable' => 'Enable', 'disable' => 'Disable', 'check' => 'Check');

				switch ($cinfo[$plugin]['status']) {
					case 0:	//Not Installed
						$links['install'] = "<a href='plugins.php?mode=install&id=$plugin'><b>Install</b></a>";
						break;
					case 1:	// Currently Active
						$links['uninstall'] = "<a href='plugins.php?mode=uninstall&id=$plugin'><b>Uninstall</b></a>";
						$links['disable'] = "<a href='plugins.php?mode=disable&id=$plugin'><b>Disable</b></a>";
						break;
					case 2:	// Needs Configuring
						$links['check'] = "<a href='plugins.php?mode=check&id=$plugin'><b>Check</b></a>";
						break;
					case 3:	// Needs Upgrade
						$links['check'] = "<a href='plugins.php?mode=check&id=$plugin'><b>Check</b></a>";
						break;
					case 4:	// Installed but not active
						$links['uninstall'] = "<a href='plugins.php?mode=uninstall&id=$plugin'><b>Uninstall</b></a>";
						$links['enable'] = "<a href='plugins.php?mode=enable&id=$plugin'><b>Enable</b></a>";
						break;
				}

				print "<td></td><td>";
				$c = 1;
				foreach ($links as $temp => $link) {
					print $link;
					if ($c < count($links))
						print ' | ';
					$c++;
				}
				print "</td>";
				print "</tr>";
			}

			print "</table>";
			if ($x == 1) {
				print "</td></tr>";
			}
			$x++;
			if ($x > 1) $x = 0;
		}
	}
	if ($x == 1)
		print "</td><td></td></tr>";
	print "</table>";
	html_end_box(TRUE);
}


function update_show_uninstalled () {
	global $pluginslist, $colors, $plugin_architecture, $config, $status_names;

	$cinfo = array();
	sort($pluginslist);

	print "<table width='100%' cellspacing=0 cellpadding=3>";
	$x = 0;

	$newplugins = array();
	$cinfo = array ();

	$path = $config['base_path'] . '/plugins/';
	$dh = opendir($path);
	while (($file = readdir($dh)) !== false) {
		if (is_dir("$path/$file")) {
			if (file_exists("$path/$file/setup.php") && !in_array($file, $pluginslist)) {
				include_once("$path/$file/setup.php");
				if (function_exists('plugin_' . $file . '_install') && function_exists('plugin_' . $file . '_version')) {
					$function = 'plugin_' . $file . '_version';
					$cinfo[$file] = $function();
					$cinfo[$file]['status'] = 0;
					$newplugins[] = $file;
				}
			}
		}
	}
	closedir($dh);

	if (count($newplugins)) {
	foreach ($newplugins as $plugin) {
		if (isset($cinfo[$plugin])) {

			if ($x == 0) {
				print "<tr><td width='50%'>";
			} else {
				print "</td><td>";
			}
			if (!isset($info[$plugin]['version']))
				$info[$plugin]['version'] = '';

			print "<table width='100%'>";
			html_header(array((isset($cinfo[$plugin]['name']) ? $cinfo[$plugin]['name'] : $plugin)), 2);
			form_alternate_row_color($colors["alternate"],$colors["light"], 0);
			print "<td width='50%'><strong>Directory:</strong></td><td>$plugin</td>";
			form_alternate_row_color($colors["alternate"],$colors["light"], 0);
			print "<td><strong>Version:</strong></td><td>" . (isset($cinfo[$plugin]['version']) ? $cinfo[$plugin]['version'] : "") . (update_check_if_newer($cinfo[$plugin]['version'], $info[$plugin]['version']) ?  ' - <font color=red><b>(Update Available!)</strong></font>' : '') . "</td>";
			form_alternate_row_color($colors["alternate"],$colors["light"], 0);
			print "<td><strong>Author:</strong></td><td>" . (isset($cinfo[$plugin]['author']) && $cinfo[$plugin]['author'] != '' ? (isset($cinfo[$plugin]['email']) && $cinfo[$plugin]['email'] != '' ? "<a href='mailto:" . $cinfo[$plugin]['email'] . "'>" . $cinfo[$plugin]['author'] . "</a>"  : $cinfo[$plugin]['author']) : "") . "</td>";
			form_alternate_row_color($colors["alternate"],$colors["light"], 0);
			print "<td><strong>Home Page:</strong></td><td>" . (isset($cinfo[$plugin]['homepage']) && $cinfo[$plugin]['homepage'] != '' ? "<a href='" . $cinfo[$plugin]['homepage'] . "'>" . $cinfo[$plugin]['homepage'] . "</a>" : "") . "</td>";
			form_alternate_row_color($colors["alternate"],$colors["light"], 0);
			print "<td><strong>Status:</strong></td><td>" . $status_names[$cinfo[$plugin]['status']] . "</td>";
			form_alternate_row_color($colors["alternate"],$colors["light"], 0);

			$links = array('install' => 'Install', 'uninstall' => 'Uninstall', 'enable' => 'Enable', 'disable' => 'Disable', 'check' => 'Check');

			switch ($cinfo[$plugin]['status']) {
				case 0:	//Not Installed
					$links['install'] = "<a href='plugins.php?mode=install&id=$plugin&tab=uninstalled'><b>Install</b></a>";
					break;
				case 1:	// Currently Active
					$links['uninstall'] = "<a href='plugins.php?mode=uninstall&id=$plugin&tab=uninstalled'><b>Uninstall</b></a>";
					$links['disable'] = "<a href='plugins.php?mode=disable&id=$plugin&tab=uninstalled'><b>Disable</b></a>";
					break;
				case 2:	// Needs Configuring
					$links['check'] = "<a href='plugins.php?mode=check&id=$plugin&tab=uninstalled'><b>Check</b></a>";
					break;
				case 3:	// Needs Upgrade
					$links['check'] = "<a href='plugins.php?mode=check&id=$plugin&tab=uninstalled'><b>Check</b></a>";
					break;
				case 4:	// Installed but not active
					$links['enable'] = "<a href='plugins.php?mode=enable&id=$plugin&tab=uninstalled'><b>Enable</b></a>";
					break;
			}

			print "<td></td><td>";
			$c = 1;
			foreach ($links as $temp => $link) {
				print $link;
				if ($c < count($links))
					print ' | ';
				$c++;
			}

			print "</td>";
			print "</tr></table>";
			if ($x == 1) {
				print "</td></tr>";
			}
			$x++;
			if ($x > 1) $x = 0;
		}
	}
	} else {
		print "<center>There are no Uninstalled Plugins</center>";
	}
	if ($x == 1)
		print "</td><td></td></tr>";
	print "</table>";
	html_end_box(TRUE);
}

function update_get_plugin_info () {
	$cinfo = array();
	$info = db_fetch_assoc("SELECT * from plugin_config");
	if (is_array($info)) {
		foreach($info as $inf) {
			$cinfo[$inf['directory']] = $inf;
			$cinfo[$inf['directory']]['changes']='';
		}
	}
	return $cinfo;
}

