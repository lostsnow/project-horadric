<?php
/*
 +-------------------------------------------------------------------------+
 | Copyright (C) 2004-2009 The Cacti Group                                 |
 |                                                                         |
 | This program is free software; you can redistribute it and/or           |
 | modify it under the terms of the GNU General Public License             |
 | as published by the Free Software Foundation; either version 2          |
 | of the License, or (at your option) any later version.                  |
 |                                                                         |
 | This program is distributed in the hope that it will be useful,         |
 | but WITHOUT ANY WARRANTY; without even the implied warranty of          |
 | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the           |
 | GNU General Public License for more details.                            |
 +-------------------------------------------------------------------------+
 | Cacti: The Complete RRDTool-based Graphing Solution                     |
 +-------------------------------------------------------------------------+
 | This code is designed, written, and maintained by the Cacti Group. See  |
 | about.php and/or the AUTHORS file for specific developer information.   |
 +-------------------------------------------------------------------------+
 | http://www.cacti.net/                                                   |
 +-------------------------------------------------------------------------+
*/

include("./include/auth.php");
include_once("./lib/export.php");

/* set default action */
if (!isset($_REQUEST["action"])) { $_REQUEST["action"] = ""; }

switch ($_REQUEST["action"]) {
	case 'save':
		form_save();

		break;
	default:
		include_once("./include/top_header.php");

		export();

		include_once("./include/bottom_footer.php");
		break;
}

/* --------------------------
    The Save Function
   -------------------------- */

function form_save() {
	global $export_types;

	if (isset($_POST["save_component_export"])) {
		$xml_data = get_item_xml($_POST["export_type"], $_POST["export_item_id"], (((isset($_POST["include_deps"]) ? $_POST["include_deps"] : "") == "") ? false : true));

		if ($_POST["output_format"] == "1") {
			include_once("./include/top_header.php");
			print "<table width='100%' align='center'><tr><td><pre>" . htmlspecialchars($xml_data) . "</pre></td></tr></table>";
			include_once("./include/bottom_footer.php");
		}elseif ($_POST["output_format"] == "2") {
			header("Content-type: application/xml; charset=UTF-8");
			print $xml_data;
		}elseif ($_POST["output_format"] == "3") {
			header("Content-type: application/xml; charset=UTF-8");
			header("Content-Disposition: attachment; filename=cacti_" . $_POST["export_type"] . "_" . strtolower(clean_up_file_name(db_fetch_cell(str_replace("|id|", $_POST["export_item_id"], $export_types{$_POST["export_type"]}["title_sql"])))) . ".xml");
			print $xml_data;
		}
	}
}

/* ---------------------------
    Template Export Functions
   --------------------------- */

function export() {
	global $colors, $export_types;

	/* 'graph_template' should be the default */
	if (!isset($_REQUEST["export_type"])) {
		$_REQUEST["export_type"] = "graph_template";
	}

	?>
	<form name="form_graph_id">
	<table width='100%' style='background-color: #f5f5f5; border: 1px solid #bbbbbb;' align='center'>
		<tr bgcolor="<?php print $colors["light"];?>">
			<td class="textArea" style="padding: 3px;">
				&nbsp;<strong>你想导出什么?</strong>&nbsp;

				<select name="cbo_graph_id" onChange="window.location=document.form_graph_id.cbo_graph_id.options[document.form_graph_id.cbo_graph_id.selectedIndex].value">
					<?php
					while (list($key, $array) = each($export_types)) {
						print "<option value='templates_export.php?export_type=$key'"; if ($_REQUEST["export_type"] == $key) { print " selected"; } print ">" . $array["name"] . "</option>\n";
					}
					?>
				</select>
			</td>
		</tr>
	</table>
	</form>
	<form method="post" action="templates_export.php">
	<?php

	html_start_box("<strong>导出模板</strong> [" . $export_types{$_REQUEST["export_type"]}["name"] . "]", "100%", $colors["header"], "3", "center", "");

	form_alternate_row_color($colors["form_alternate1"],$colors["form_alternate2"],0); ?>
		<td width="50%">
			<font class="textEditTitle"><?php print $export_types{$_REQUEST["export_type"]}["name"];?> 导出</font><br>
			选择导出到XML中的确切项目.
		</td>
		<td>
			<?php form_dropdown("export_item_id",db_fetch_assoc($export_types{$_REQUEST["export_type"]}["dropdown_sql"]),"name","id","","","0");?>
		</td>
	</tr>

	<?php form_alternate_row_color($colors["form_alternate1"],$colors["form_alternate2"],1); ?>
		<td width="50%">
			<font class="textEditTitle">包含依存关系</font><br>
			有些模板依赖于Cacti中的其它项目以保证功能完整. 强烈建议选择此项,否则导入可能失败.
		</td>
		<td>
			<?php form_checkbox("include_deps", "on", "包括依存关系", "on", "", true);?>
		</td>
	</tr>

	<?php form_alternate_row_color($colors["form_alternate1"],$colors["form_alternate2"],0); ?>
		<td width="50%">
			<font class="textEditTitle">输出格式</font><br>
			选择在哪输出XML文件.
		</td>
		<td>
			<?php
			form_radio_button("output_format", "3", "1", "输出到浏览器 (在Cacti中)","1",true); print "<br>";
			form_radio_button("output_format", "3", "2", "输出到浏览器 (raw XML)","1",true); print "<br>";
			form_radio_button("output_format", "3", "3", "保存到本地文件","1",true);
			?>
		</td>
	</tr>
	<?php

	form_hidden_box("export_type", $_REQUEST["export_type"], "");
	form_hidden_box("save_component_export","1","");

	html_end_box();

	form_save_button("templates_export.php");
}
?>
