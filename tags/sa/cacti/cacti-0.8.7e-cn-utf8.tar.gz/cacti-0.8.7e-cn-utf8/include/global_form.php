<?php
/*
 +-------------------------------------------------------------------------+
 | Copyright (C) 2004-2009 The Cacti Group                                 |
 |                                                                         |
 | This program is free software; you can redistribute it and/or           |
 | modify it under the terms of the GNU General Public License             |
 | as published by the Free Software Foundation; either version 2          |
 | of the License, or (at your option) any later version.                  |
 |                                                                         |
 | This program is distributed in the hope that it will be useful,         |
 | but WITHOUT ANY WARRANTY; without even the implied warranty of          |
 | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the           |
 | GNU General Public License for more details.                            |
 +-------------------------------------------------------------------------+
 | Cacti: The Complete RRDTool-based Graphing Solution                     |
 +-------------------------------------------------------------------------+
 | This code is designed, written, and maintained by the Cacti Group. See  |
 | about.php and/or the AUTHORS file for specific developer information.   |
 +-------------------------------------------------------------------------+
 | http://www.cacti.net/                                                   |
 +-------------------------------------------------------------------------+
*/

if (!defined("VALID_HOST_FIELDS")) {
	define("VALID_HOST_FIELDS", "(hostname|snmp_community|snmp_username|snmp_password|snmp_auth_protocol|snmp_priv_passphrase|snmp_priv_protocol|snmp_context|snmp_version|snmp_port|snmp_timeout)");
}

/* file: cdef.php, action: edit */
$fields_cdef_edit = array(
	"name" => array(
		"method" => "textbox",
		"friendly_name" => "名称",
		"description" => "有用的CDEF名称.",
		"value" => "|arg1:name|",
		"max_length" => "255",
		"size" => "60"
		),
	"id" => array(
		"method" => "hidden_zero",
		"value" => "|arg1:id|"
		),
	"save_component_cdef" => array(
		"method" => "hidden",
		"value" => "1"
		)
	);

/* file: color.php, action: edit */
$fields_color_edit = array(
	"hex" => array(
		"method" => "textbox",
		"friendly_name" => "Hex值",
		"description" => "颜色的十六进制值; 有效范围: 000000-FFFFFF.",
		"value" => "|arg1:hex|",
		"max_length" => "6",
		),
	"id" => array(
		"method" => "hidden_zero",
		"value" => "|arg1:id|"
		),
	"save_component_color" => array(
		"method" => "hidden",
		"value" => "1"
		)
	);

/* file: data_input.php, action: edit */
$fields_data_input_edit = array(
	"name" => array(
		"method" => "textbox",
		"friendly_name" => "名称",
		"description" => "输入数据输入方式的名称.",
		"value" => "|arg1:name|",
		"max_length" => "255",
		),
	"type_id" => array(
		"method" => "drop_array",
		"friendly_name" => "输入类型",
		"description" => "选择数据输入方式的类型.",
		"value" => "|arg1:type_id|",
		"array" => $input_types,
		),
	"input_string" => array(
		"method" => "textbox",
		"friendly_name" => "输入字符串",
		"description" => "发送给脚本的数据, 其中包括脚本的完整路径和输入源(在&lt;&gt;括号中).",
		"value" => "|arg1:input_string|",
		"max_length" => "255",
		),
	"id" => array(
		"method" => "hidden_zero",
		"value" => "|arg1:id|"
		),
	"save_component_data_input" => array(
		"method" => "hidden",
		"value" => "1"
		)
	);

/* file: data_input.php, action: field_edit (dropdown) */
$fields_data_input_field_edit_1 = array(
	"data_name" => array(
		"method" => "drop_array",
		"friendly_name" => "域 [|arg1:|]",
		"description" => "从 |arg1:| 中选择与数据相关的区域.",
		"value" => "|arg3:data_name|",
		"array" => "|arg2:|",
		)
	);

/* file: data_input.php, action: field_edit (textbox) */
$fields_data_input_field_edit_2 = array(
	"data_name" => array(
		"method" => "textbox",
		"friendly_name" => "域 [|arg1:|]",
		"description" => "输入 |arg1:| 域的名称.",
		"value" => "|arg2:data_name|",
		"max_length" => "50",
		)
	);

/* file: data_input.php, action: field_edit */
$fields_data_input_field_edit = array(
	"name" => array(
		"method" => "textbox",
		"friendly_name" => "标注",
		"description" => "输入数据输入方式的简短注释.",
		"value" => "|arg1:name|",
		"max_length" => "200",
		),
	"update_rra" => array(
		"method" => "checkbox",
		"friendly_name" => "更新RRD文件",
		"description" => "此输出域的数据是否加入rrd文件.",
		"value" => "|arg1:update_rra|",
		"default" => "on",
		"form_id" => "|arg1:id|"
		),
	"regexp_match" => array(
		"method" => "textbox",
		"friendly_name" => "正则表达式匹配",
		"description" => "如果你需要特定的正则表达式来匹配数据,在此输入(ereg格式).",
		"value" => "|arg1:regexp_match|",
		"max_length" => "200"
		),
	"allow_nulls" => array(
		"method" => "checkbox",
		"friendly_name" => "允许空输入",
		"description" => "允许用户对此域的输入为空(NULL).",
		"value" => "|arg1:allow_nulls|",
		"default" => "",
		"form_id" => false
		),
	"type_code" => array(
		"method" => "textbox",
		"friendly_name" => "专用类型代码",
		"description" => "如果此域被设备模板特殊对待,在此表明. 此域合法的关键字有 'hostname', 'snmp_community', 'snmp_username', 'snmp_password', 'snmp_auth_protocol', 'snmp_priv_passphrase', 'snmp_priv_protocol', 'snmp_port', 'snmp_timeout' 和 'snmp_version'.",
		"value" => "|arg1:type_code|",
		"max_length" => "40"
		),
	"id" => array(
		"method" => "hidden_zero",
		"value" => "|arg1:id|"
		),
	"input_output" => array(
		"method" => "hidden",
		"value" => "|arg2:|"
		),
	"sequence" => array(
		"method" => "hidden_zero",
		"value" => "|arg1:sequence|"
		),
	"data_input_id" => array(
		"method" => "hidden_zero",
		"value" => "|arg3:data_input_id|"
		),
	"save_component_field" => array(
		"method" => "hidden",
		"value" => "1"
		)
	);

/* file: data_templates.php, action: template_edit */
$fields_data_template_template_edit = array(
	"template_name" => array(
		"method" => "textbox",
		"friendly_name" => "名称",
		"description" => "数据模板的名称.",
		"value" => "|arg1:name|",
		"max_length" => "150",
		),
	"data_template_id" => array(
		"method" => "hidden_zero",
		"value" => "|arg2:data_template_id|"
		),
	"data_template_data_id" => array(
		"method" => "hidden_zero",
		"value" => "|arg2:id|"
		),
	"current_rrd" => array(
		"method" => "hidden_zero",
		"value" => "|arg3:view_rrd|"
		),
	"save_component_template" => array(
		"method" => "hidden",
		"value" => "1"
		)
	);

/* file: (data_sources.php|data_templates.php), action: (ds|template)_edit */
$struct_data_source = array(
	"name" => array(
		"friendly_name" => "名称",
		"method" => "textbox",
		"max_length" => "250",
		"default" => "",
		"description" => "为此数据源选择名称.",
		"flags" => ""
		),
	"data_source_path" => array(
		"friendly_name" => "数据源路径",
		"method" => "textbox",
		"max_length" => "255",
		"default" => "",
		"description" => "RRD文件的完整路径.",
		"flags" => "NOTEMPLATE"
		),
	"data_input_id" => array(
		"friendly_name" => "数据输入方式",
		"method" => "drop_sql",
		"sql" => "select id,name from data_input order by name",
		"default" => "",
		"none_value" => "无",
		"description" => "用来为此数据源轮询数据的脚本/源.",
		"flags" => "ALWAYSTEMPLATE"
		),
	"rra_id" => array(
		"method" => "drop_multi_rra",
		"friendly_name" => "相关循环档",
		"description" => "当输入数据时使用哪些循环档. (建议选择所有的值).",
		"form_id" => "|arg1:id|",
		"sql" => "select rra_id as id,data_template_data_id from data_template_data_rra where data_template_data_id=|arg1:id|",
		"sql_all" => "select rra.id from rra order by id",
		"sql_print" => "select rra.name from (data_template_data_rra,rra) where data_template_data_rra.rra_id=rra.id and data_template_data_rra.data_template_data_id=|arg1:id|",
		"flags" => "ALWAYSTEMPLATE"
		),
	"rrd_step" => array(
		"friendly_name" => "间歇",
		"method" => "textbox",
		"max_length" => "10",
		"size" => "20",
		"default" => "300",
		"description" => "更新时间间隔(以秒计).",
		"flags" => ""
		),
	"active" => array(
		"friendly_name" => "数据源启用",
		"method" => "checkbox",
		"default" => "on",
		"description" => "Cacti是否从此数据源获取数据.",
		"flags" => ""
		)
	);

/* file: (data_sources.php|data_templates.php), action: (ds|template)_edit */
$struct_data_source_item = array(
	"data_source_name" => array(
		"friendly_name" => "内部数据源名称",
		"method" => "textbox",
		"max_length" => "19",
		"default" => "",
		"description" => "选择唯一的名称来表示在RRD文件中的此段数据."
		),
	"rrd_minimum" => array(
		"friendly_name" => "最小值",
		"method" => "textbox",
		"max_length" => "20",
		"size" => "30",
		"default" => "0",
		"description" => "允许轮询的数据最小值."
		),
	"rrd_maximum" => array(
		"friendly_name" => "最大值",
		"method" => "textbox",
		"max_length" => "20",
		"size" => "30",
		"default" => "0",
		"description" => "允许轮询的数据最大值."
		),
	"data_source_type_id" => array(
		"friendly_name" => "数据源类型",
		"method" => "drop_array",
		"array" => $data_source_types,
		"default" => "",
		"description" => "在循环档中数据如何表示."
		),
	"rrd_heartbeat" => array(
		"friendly_name" => "心跳",
		"method" => "textbox",
		"max_length" => "20",
		"size" => "30",
		"default" => "600",
		"description" => "在数据输入变为不可识别(\"unknown\")前经过的最大时间. (通常 2x300=600).
			(Usually 2x300=600)"
		),
	"data_input_field_id" => array(
		"friendly_name" => "输出域",
		"method" => "drop_sql",
		"default" => "0",
		"description" => "在轮询数据时,此域的数据将被放入数据源中."
		)
	);

/* file: grprint_presets.php, action: edit */
$fields_grprint_presets_edit = array(
	"name" => array(
		"method" => "textbox",
		"friendly_name" => "名称",
		"description" => "输入图像打印预置名称,确认是你可识别的东西.",
		"value" => "|arg1:name|",
		"max_length" => "50",
		),
	"gprint_text" => array(
		"method" => "textbox",
		"friendly_name" => "图像打印文本",
		"description" => "输入自定义的图像打印字符串.",
		"value" => "|arg1:gprint_text|",
		"max_length" => "50",
		),
	"id" => array(
		"method" => "hidden_zero",
		"value" => "|arg1:id|"
		),
	"save_component_gprint_presets" => array(
		"method" => "hidden",
		"value" => "1"
		)
	);

/* file: (graphs.php|graph_templates.php), action: (graph|template)_edit */
$struct_graph = array(
	"title" => array(
		"friendly_name" => "标题 (--title)",
		"method" => "textbox",
		"max_length" => "255",
		"default" => "",
		"description" => "打印在图像上的名称."
		),
	"image_format_id" => array(
		"friendly_name" => "图像格式 (--imgformat)",
		"method" => "drop_array",
		"array" => $image_types,
		"default" => "1",
		"description" => "图像生成格式; PNG, GIF 或 SVG. 图像格式支持随RRDtool而定."
		),
	"height" => array(
		"friendly_name" => "高度 (--height)",
		"method" => "textbox",
		"max_length" => "50",
		"default" => "120",
		"description" => "图像的高度(像素)."
		),
	"width" => array(
		"friendly_name" => "宽度 (--width)",
		"method" => "textbox",
		"max_length" => "50",
		"default" => "500",
		"description" => "图像的宽度(像素)."
		),
	"slope_mode" => array(
		"friendly_name" => "倾斜模式 (--slope-mode)",
		"method" => "checkbox",
		"default" => "on",
		"description" => "在大于等于RRDtool 1.2.x中使用倾斜模式,平滑图像外形将以分辨率损失为代价."
		),
	"auto_scale" => array(
		"friendly_name" => "自动刻度",
		"method" => "checkbox",
		"default" => "on",
		"description" => "自动刻度纵坐标替代定义的上限和下限. 注: 选择此项,上限和下限将被忽略."
		),
	"auto_scale_opts" => array(
		"friendly_name" => "自动刻度选项",
		"method" => "radio",
		"default" => "2",
		"description" => "使用 <br>
			--alt-autoscale 刻度绝对最大和最小值 <br>
		    --alt-autoscale-max 刻度最大值,使用指定的下限 <br>
		    --alt-autoscale-min 刻度最小值,使用指定的上限 <br>
			--alt-autoscale (有界) 刻度使用上限和下限(RRDtool默认) <br>
		    ",
		"items" => array(
			0 => array(
				"radio_value" => "1",
				"radio_caption" => "使用 --alt-autoscale (忽略界限)"
				),
			1 => array(
				"radio_value" => "2",
				"radio_caption" => "使用 --alt-autoscale-max (接受下限)"
				),
			2 => array(
				"radio_value" => "3",
				"radio_caption" => "使用 --alt-autoscale-min (接受上限,需要RRDtool 1.2.x)"
				),
			3 => array(
				"radio_value" => "4",
				"radio_caption" => "使用 --alt-autoscale (接受上下限,RRDtool默认)"
				)
			)
		),
	"auto_scale_log" => array(
		"friendly_name" => "对数刻度(--logarithmic)",
		"method" => "checkbox",
		"default" => "",
		"on_change" => "changeScaleLog()",
		"description" => "使用对数纵坐标刻度"
		),
	"scale_log_units" => array(
		"friendly_name" => "对数刻度的公制单位(--units=si)",
		"method" => "checkbox",
		"default" => "",
		"description" => "使用对数刻度的公制单位取代指数计数(rrdtool-1.0.x中不可用).<br>注:线状图默认使用公制单位."
		),
	"auto_scale_rigid" => array(
		"friendly_name" => "固定边界模式(--rigid)",
		"method" => "checkbox",
		"default" => "",
		"description" => "如果图像包含有越界数据,不扩大上限和下限."
		),
	"auto_padding" => array(
		"friendly_name" => "自动填充",
		"method" => "checkbox",
		"default" => "on",
		"description" => "填充文本以便图例和图像数据总是排成直线. 注:由于大量的开销,可能造成图像交付时间加长,同时自动填充并非在所有的图像类型中都能精确,一致的标签通常会有帮助."
		),
	"export" => array(
		"friendly_name" => "允许图像导出",
		"method" => "checkbox",
		"default" => "on",
		"description" => "如果使用Cacti的导出功能,选择是否将此图像导出为静态的html/png."
		),
	"upper_limit" => array(
		"friendly_name" => "上限(--upper-limit)",
		"method" => "textbox",
		"max_length" => "50",
		"default" => "100",
		"description" => "rrd图像纵向最大值."
		),
	"lower_limit" => array(
		"friendly_name" => "下限(--lower-limit)",
		"method" => "textbox",
		"max_length" => "255",
		"default" => "0",
		"description" => "rrd图像纵向最小值."
		),
	"base_value" => array(
		"friendly_name" => "基值(--base)",
		"method" => "textbox",
		"max_length" => "50",
		"default" => "1000",
		"description" => "应设为1024(内存)或1000(流量测量)."
		),
	"unit_value" => array(
		"friendly_name" => "单位网格值(--unit/--y-grid)",
		"method" => "textbox",
		"max_length" => "50",
		"default" => "",
		"description" => "设置纵坐标指数值的数量. 注: 此选项在RRDtool 1.0.36中添加,在1.2.x去除. 在1.2.x中,被替换为--y-grid选项.使用此项,纵坐标网格线在每个网格间歇上显示,并在每标记行上放置标签."
		),
	"unit_exponent_value" => array(
		"friendly_name" => "单位指数值(--units-exponent)",
		"method" => "textbox",
		"max_length" => "50",
		"default" => "",
		"description" => "Cacti在纵坐标上使用的单位.3表示用'k'显示所有,-6表示'u'(micro)显示所有."
		),
	"vertical_label" => array(
		"friendly_name" => "纵向标签(--vertical-label)",
		"method" => "textbox",
		"max_length" => "255",
		"default" => "",
		"description" => "在图像左边显示纵向标签."
		)
	);

/* file: (graphs.php|graph_templates.php), action: item_edit */
$struct_graph_item = array(
	"task_item_id" => array(
		"friendly_name" => "数据源",
		"method" => "drop_sql",
		"sql" => "select
			CONCAT_WS('',case when host.description is null then 'No Host' when host.description is not null then host.description end,' - ',data_template_data.name,' (',data_template_rrd.data_source_name,')') as name,
			data_template_rrd.id
			from (data_template_data,data_template_rrd,data_local)
			left join host on (data_local.host_id=host.id)
			where data_template_rrd.local_data_id=data_local.id
			and data_template_data.local_data_id=data_local.id
			order by name",
		"default" => "0",
		"none_value" => "无",
		"description" => "此图像项目使用的数据源."
		),
	"color_id" => array(
		"friendly_name" => "颜色",
		"method" => "drop_color",
		"default" => "0",
		"on_change" => "changeColorId()",
		"description" => "图例使用的颜色."
		),
	"alpha" => array(
		"friendly_name" => "暗度/透明度通道",
		"method" => "drop_array",
		"default" => "FF",
		"array" => $graph_color_alpha,
		"description" => "颜色的暗度/透明度通道. rrdtool-1.0.x中不可用."
		),
	"graph_type_id" => array(
		"friendly_name" => "图像项目类型",
		"method" => "drop_array",
		"array" => $graph_item_types,
		"default" => "0",
		"description" => "在图像中此项数据的视觉表示形式."
		),
	"consolidation_function_id" => array(
		"friendly_name" => "合并函数",
		"method" => "drop_array",
		"array" => $consolidation_functions,
		"default" => "0",
		"description" => "在图像中此项的数据统计上的表示."
		),
	"cdef_id" => array(
		"friendly_name" => "CDEF函数",
		"method" => "drop_sql",
		"sql" => "select id,name from cdef order by name",
		"default" => "0",
		"none_value" => "无",
		"description" => "在图像中此项所使用的CDEF(数学)函数."
		),
	"value" => array(
		"friendly_name" => "值",
		"method" => "textbox",
		"max_length" => "50",
		"default" => "",
		"description" => "纵标尺或横标尺图像项目的值."
		),
	"gprint_id" => array(
		"friendly_name" => "图像打印类型",
		"method" => "drop_sql",
		"sql" => "select id,name from graph_templates_gprint order by name",
		"default" => "2",
		"description" => "如果图像项目是图像打印, 你可以在此随意选择其它格式. 你能在\"图像打印预置\"下定义额外的类型."
		),
	"text_format" => array(
		"friendly_name" => "文本格式",
		"method" => "textbox",
		"max_length" => "255",
		"default" => "",
		"description" => "此图像项目在图例中显示的文本."
		),
	"hard_return" => array(
		"friendly_name" => "插入硬回车",
		"method" => "checkbox",
		"default" => "",
		"description" => "强制此项目后的图例另起一行."
		),
	"sequence" => array(
		"friendly_name" => "序列",
		"method" => "view"
		)
	);

/* file: graph_templates.php, action: template_edit */
$fields_graph_template_template_edit = array(
	"name" => array(
		"method" => "textbox",
		"friendly_name" => "名称",
		"description" => "图像模板名称.",
		"value" => "|arg1:name|",
		"max_length" => "150",
		),
	"graph_template_id" => array(
		"method" => "hidden_zero",
		"value" => "|arg2:graph_template_id|"
		),
	"graph_template_graph_id" => array(
		"method" => "hidden_zero",
		"value" => "|arg2:id|"
		),
	"save_component_template" => array(
		"method" => "hidden",
		"value" => "1"
		)
	);

/* file: graph_templates.php, action: input_edit */
$fields_graph_template_input_edit = array(
	"name" => array(
		"method" => "textbox",
		"friendly_name" => "名称",
		"description" => "图像项目输入名称,确认是你可识别的东西..",
		"value" => "|arg1:name|",
		"max_length" => "50"
		),
	"description" => array(
		"method" => "textarea",
		"friendly_name" => "描述",
		"description" => "输入图像项目输入的描述,描述此输入如何使用.",
		"value" => "|arg1:description|",
		"textarea_rows" => "5",
		"textarea_cols" => "40"
		),
	"column_name" => array(
		"method" => "drop_array",
		"friendly_name" => "域类型",
		"description" => "在图像中数据如何表示.",
		"value" => "|arg1:column_name|",
		"array" => "|arg2:|",
		),
	"graph_template_id" => array(
		"method" => "hidden_zero",
		"value" => "|arg3:graph_template_id|"
		),
	"graph_template_input_id" => array(
		"method" => "hidden_zero",
		"value" => "|arg3:id|"
		),
	"save_component_input" => array(
		"method" => "hidden",
		"value" => "1"
		)
	);

/* file: host.php, action: edit */
$fields_host_edit = array(
	"host_header" => array(
		"method" => "spacer",
		"friendly_name" => "设备通用项"
		),
	"description" => array(
		"method" => "textbox",
		"friendly_name" => "描述",
		"description" => "给此设备一个有意义的描述.",
		"value" => "|arg1:description|",
		"max_length" => "250",
		),
	"hostname" => array(
		"method" => "textbox",
		"friendly_name" => "设备名",
		"description" => "此设备的有效设备全名或IP地址.",
		"value" => "|arg1:hostname|",
		"max_length" => "250",
		),
	"host_template_id" => array(
		"method" => "drop_sql",
		"friendly_name" => "设备模板",
		"description" => "选择设备类型,模板. 设备模板管理此类型的设备轮询何种数据.",
		"value" => "|arg1:host_template_id|",
		"none_value" => "无",
		"sql" => "select id,name from host_template order by name",
		),
	"disabled" => array(
		"method" => "checkbox",
		"friendly_name" => "停用设备",
		"description" => "选择此项将停止对此设备的所有检测.",
		"value" => "|arg1:disabled|",
		"default" => "",
		"form_id" => false
		),
	"availability_header" => array(
		"method" => "spacer",
		"friendly_name" => "可用性/可达性选项"
		),
	"availability_method" => array(
		"friendly_name" => "离线设备检测",
		"description" => "Cacti使用此方式确定设备是否可用于轮询.  <br><i>注: 至少,总是推荐选择SNMP.</i>",
		"on_change" => "changeHostForm()",
		"value" => "|arg1:availability_method|",
		"method" => "drop_array",
		"default" => read_config_option("availability_method"),
		"array" => $availability_options
		),
	"ping_method" => array(
		"friendly_name" => "Ping方式",
		"description" => "发送ping包的类型.  <br><i>注: Linux/UNIX中使用ICMP需要root权限.</i>",
		"on_change" => "changeHostForm()",
		"value" => "|arg1:ping_method|",
		"method" => "drop_array",
		"default" => read_config_option("ping_method"),
		"array" => $ping_methods
		),
	"ping_port" => array(
		"method" => "textbox",
		"friendly_name" => "Ping端口",
		"value" => "|arg1:ping_port|",
		"description" => "试图连接的TCP或UDP端口.",
		"default" => read_config_option("ping_port"),
		"max_length" => "50",
		"size" => "15"
		),
	"ping_timeout" => array(
		"friendly_name" => "Ping超时值",
		"description" => "设备ICMP和UDP Ping超时值,此设备SNMP的超时值应用于SNMP Ping.",
		"method" => "textbox",
		"value" => "|arg1:ping_timeout|",
		"default" => read_config_option("ping_timeout"),
		"max_length" => "10",
		"size" => "15"
		),
	"ping_retries" => array(
		"friendly_name" => "Ping重试计数",
		"description" => "Cacti在确定设备失败前,尝试Ping的次数.",
		"method" => "textbox",
		"value" => "|arg1:ping_retries|",
		"default" => read_config_option("ping_retries"),
		"max_length" => "10",
		"size" => "15"
		),
	"spacer1" => array(
		"method" => "spacer",
		"friendly_name" => "SNMP选项"
		),
	"snmp_version" => array(
		"method" => "drop_array",
		"friendly_name" => "SNMP版本",
		"description" => "选择此设备使用的SNMP版本.",
		"on_change" => "changeHostForm()",
		"value" => "|arg1:snmp_version|",
		"default" => read_config_option("snmp_ver"),
		"array" => $snmp_versions,
		),
	"snmp_community" => array(
		"method" => "textbox",
		"friendly_name" => "SNMP连接字串",
		"description" => "此设备的SNMP读取连接字串.",
		"value" => "|arg1:snmp_community|",
		"form_id" => "|arg1:id|",
		"default" => read_config_option("snmp_community"),
		"max_length" => "100",
		"size" => "15"
		),
	"snmp_username" => array(
		"method" => "textbox",
		"friendly_name" => "SNMP(v3)用户名",
		"description" => "设备SNMPv3的用户名.",
		"value" => "|arg1:snmp_username|",
		"default" => read_config_option("snmp_username"),
		"max_length" => "50",
		"size" => "15"
		),
	"snmp_password" => array(
		"method" => "textbox_password",
		"friendly_name" => "SNMP(v3)密码",
		"description" => "设备SNMPv3的密码.",
		"value" => "|arg1:snmp_password|",
		"default" => read_config_option("snmp_password"),
		"max_length" => "50",
		"size" => "15"
		),
	"snmp_auth_protocol" => array(
		"method" => "drop_array",
		"friendly_name" => "SNMP(v3)认证协议",
		"description" => "选择SNMPv3认证协议.",
		"value" => "|arg1:snmp_auth_protocol|",
		"default" => read_config_option("snmp_auth_protocol"),
		"array" => $snmp_auth_protocols,
		),
	"snmp_priv_passphrase" => array(
		"method" => "textbox",
		"friendly_name" => "SNMP(v3)加密短语",
		"description" => "选择SNMPv3的加密短语.",
		"value" => "|arg1:snmp_priv_passphrase|",
		"default" => read_config_option("snmp_priv_passphrase"),
		"max_length" => "200",
		"size" => "40"
		),
	"snmp_priv_protocol" => array(
		"method" => "drop_array",
		"friendly_name" => "SNMP(v3)加密协议",
		"description" => "选择SNMPv3的加密协议.",
		"value" => "|arg1:snmp_priv_protocol|",
		"default" => read_config_option("snmp_priv_protocol"),
		"array" => $snmp_priv_protocols,
		),
	"snmp_context" => array(
		"method" => "textbox",
		"friendly_name" => "SNMP上下文",
		"description" => "此设备所使用的SNMP上下文.",
		"value" => "|arg1:snmp_context|",
		"default" => "",
		"max_length" => "64",
		"size" => "25"
		),
	"snmp_port" => array(
		"method" => "textbox",
		"friendly_name" => "SNMP端口",
		"description" => "SNMP使用的UDP端口(默认为161).",
		"value" => "|arg1:snmp_port|",
		"max_length" => "5",
		"default" => read_config_option("snmp_port"),
		"size" => "15"
		),
	"snmp_timeout" => array(
		"method" => "textbox",
		"friendly_name" => "SNMP超时",
		"description" => "Cacti等待SNMP应答的最大毫秒值 (不与php-snmp支持同时工作).",
		"value" => "|arg1:snmp_timeout|",
		"max_length" => "8",
		"default" => read_config_option("snmp_timeout"),
		"size" => "15"
		),
	"max_oids" => array(
		"method" => "textbox",
		"friendly_name" => "每个获取请求的最大OID's",
		"description" => "规定单个SNMP获取请求获得的OID's数目.",
		"value" => "|arg1:max_oids|",
		"max_length" => "8",
		"default" => read_config_option("max_get_size"),
		"size" => "15"
		),
	"header4" => array(
		"method" => "spacer",
		"friendly_name" => "附加选项"
		),
	"notes" => array(
		"method" => "textarea",
		"friendly_name" => "注释",
		"description" => "填写此设备的注释.",
		"class" => "textAreaNotes",
		"value" => "|arg1:notes|",
		"textarea_rows" => "5",
		"textarea_cols" => "50"
		),
	"id" => array(
		"method" => "hidden_zero",
		"value" => "|arg1:id|"
		),
	"_host_template_id" => array(
		"method" => "hidden_zero",
		"value" => "|arg1:host_template_id|"
		),
	"save_component_host" => array(
		"method" => "hidden",
		"value" => "1"
		)
	);

/* file: host_templates.php, action: edit */
$fields_host_template_edit = array(
	"name" => array(
		"method" => "textbox",
		"friendly_name" => "名称",
		"description" => "设备模板的名称.",
		"value" => "|arg1:name|",
		"max_length" => "255",
		),
	"id" => array(
		"method" => "hidden_zero",
		"value" => "|arg1:id|"
		),
	"save_component_template" => array(
		"method" => "hidden",
		"value" => "1"
		)
	);

/* file: rra.php, action: edit */
$fields_rra_edit = array(
	"name" => array(
		"method" => "textbox",
		"friendly_name" => "名称",
		"description" => "循环档名称.",
		"value" => "|arg1:name|",
		"max_length" => "100",
		),
	"consolidation_function_id" => array(
		"method" => "drop_multi",
		"friendly_name" => "合并函数",
		"description" => "循环档中如何输入数据.",
		"array" => $consolidation_functions,
		"sql" => "select consolidation_function_id as id,rra_id from rra_cf where rra_id=|arg1:id|",
		),
	"x_files_factor" => array(
		"method" => "textbox",
		"friendly_name" => "X-文件因数",
		"description" => "未知数据数量依被视为已知.",
		"value" => "|arg1:x_files_factor|",
		"max_length" => "10",
		),
	"steps" => array(
		"method" => "textbox",
		"friendly_name" => "间歇",
		"description" => "需要在循环档中放入多少数据点.",
		"value" => "|arg1:steps|",
		"max_length" => "8",
		),
	"rows" => array(
		"method" => "textbox",
		"friendly_name" => "行",
		"description" => "在循环档中保存多少生成数据.",
		"value" => "|arg1:rows|",
		"max_length" => "12",
		),
	"timespan" => array(
		"method" => "textbox",
		"friendly_name" => "时间段",
		"description" => "此循环档的图像显示多少秒.",
		"value" => "|arg1:timespan|",
		"max_length" => "12",
		),
	"id" => array(
		"method" => "hidden_zero",
		"value" => "|arg1:id|"
		),
	"save_component_rra" => array(
		"method" => "hidden",
		"value" => "1"
		)
	);

/* file: data_queries.php, action: edit */
$fields_data_query_edit = array(
	"name" => array(
		"method" => "textbox",
		"friendly_name" => "名称",
		"description" => "数据查询名称.",
		"value" => "|arg1:name|",
		"max_length" => "100",
		),
	"description" => array(
		"method" => "textbox",
		"friendly_name" => "描述",
		"description" => "此数据查询的描述.",
		"value" => "|arg1:description|",
		"max_length" => "255",
		),
	"xml_path" => array(
		"method" => "textbox",
		"friendly_name" => "XML路径",
		"description" => "包含数据查询定义的XML文件的完整路径.",
		"value" => "|arg1:xml_path|",
		"default" => "<path_cacti>/resource/",
		"max_length" => "255",
		),
	"data_input_id" => array(
		"method" => "drop_sql",
		"friendly_name" => "数据输入方式",
		"description" => "选择设备,设备模板类型. 设备模板控制数据从此类设备中轮询什么类型的数据.",
		"value" => "|arg1:data_input_id|",
		"sql" => "select id,name from data_input where (type_id=3 or type_id=4 or type_id=5 or type_id=6) order by name",
		),
	"id" => array(
		"method" => "hidden_zero",
		"value" => "|arg1:id|",
		),
	"save_component_snmp_query" => array(
		"method" => "hidden",
		"value" => "1"
		)
	);

/* file: data_queries.php, action: item_edit */
$fields_data_query_item_edit = array(
	"name" => array(
		"method" => "textbox",
		"friendly_name" => "名称",
		"description" => "相关图像的名称.",
		"value" => "|arg1:name|",
		"max_length" => "100",
		),
	"graph_template_id" => array(
		"method" => "drop_sql",
		"friendly_name" => "图像模板",
		"description" => "选择设备,设备模板类型. 设备模板控制数据从此类设备中轮询什么类型的数据.",
		"value" => "|arg1:graph_template_id|",
		"sql" => "select id,name from graph_templates order by name",
		),
	"id" => array(
		"method" => "hidden_zero",
		"value" => "|arg1:id|"
		),
	"snmp_query_id" => array(
		"method" => "hidden_zero",
		"value" => "|arg2:snmp_query_id|"
		),
	"_graph_template_id" => array(
		"method" => "hidden_zero",
		"value" => "|arg1:graph_template_id|"
		),
	"save_component_snmp_query_item" => array(
		"method" => "hidden",
		"value" => "1"
		)
	);

/* file: tree.php, action: edit */
$fields_tree_edit = array(
	"name" => array(
		"method" => "textbox",
		"friendly_name" => "名称",
		"description" => "图像树的有效名称.",
		"value" => "|arg1:name|",
		"max_length" => "255",
		),
	"sort_type" => array(
		"method" => "drop_array",
		"friendly_name" => "排序类型",
		"description" => "选择树中项目如何排序.",
		"value" => "|arg1:sort_type|",
		"array" => $tree_sort_types,
		),
	"id" => array(
		"method" => "hidden_zero",
		"value" => "|arg1:id|"
		),
	"save_component_tree" => array(
		"method" => "hidden",
		"value" => "1"
		)
	);

/* file: user_admin.php, action: user_edit (host) */
$fields_user_user_edit_host = array(
	"username" => array(
		"method" => "textbox",
		"friendly_name" => "用户名",
		"description" => "用户登录的名称.",
		"value" => "|arg1:username|",
		"max_length" => "255"
		),
	"full_name" => array(
		"method" => "textbox",
		"friendly_name" => "全名",
		"description" => "用户更具描述性的名称, 可以包含空格及特殊符号.",
		"value" => "|arg1:full_name|",
		"max_length" => "255"
		),
	"password" => array(
		"method" => "textbox_password",
		"friendly_name" => "密码",
		"description" => "为此用户输入两次密码. 请记住密码区分大小写!",
		"value" => "",
		"max_length" => "255"
		),
	"enabled" => array(
		"method" => "checkbox",
		"friendly_name" => "启用",
		"description" => "确定用户是否能够登录.",
		"value" => "|arg1:enabled|",
		"default" => ""
		),
	"grp1" => array(
		"friendly_name" => "账户选项",
		"method" => "checkbox_group",
		"description" => "设置用户账号的特殊选顶.",
		"items" => array(
			"must_change_password" => array(
				"value" => "|arg1:must_change_password|",
				"friendly_name" => "用户必须在下次登录时更改密码",
				"form_id" => "|arg1:id|",
				"default" => ""
				),
			"graph_settings" => array(
				"value" => "|arg1:graph_settings|",
				"friendly_name" => "允许用户保存自定义图像设置",
				"form_id" => "|arg1:id|",
				"default" => "on"
				)
			)
		),
	"grp2" => array(
		"friendly_name" => "图像选项",
		"method" => "checkbox_group",
		"description" => "设置图像的特殊选项.",
		"items" => array(
			"show_tree" => array(
				"value" => "|arg1:show_tree|",
				"friendly_name" => "用户有树状查看权限",
				"form_id" => "|arg1:id|",
				"default" => "on"
				),
			"show_list" => array(
				"value" => "|arg1:show_list|",
				"friendly_name" => "用户有列表查看权限",
				"form_id" => "|arg1:id|",
				"default" => "on"
				),
			"show_preview" => array(
				"value" => "|arg1:show_preview|",
				"friendly_name" => "用户有预览查看权限",
				"form_id" => "|arg1:id|",
				"default" => "on"
				)
			)
		),
	"login_opts" => array(
		"friendly_name" => "登录选项",
		"method" => "radio",
		"default" => "1",
		"description" => "用户登录时将做什么.",
		"value" => "|arg1:login_opts|",
		"items" => array(
			0 => array(
				"radio_value" => "1",
				"radio_caption" => "显示用户在浏览器中指定的页面."
				),
			1 => array(
				"radio_value" => "2",
				"radio_caption" => "显示默认控制面板的屏幕."
				),
			2 => array(
				"radio_value" => "3",
				"radio_caption" => "显示默认图像查看屏幕."
				)
			)
		),
	"realm" => array(
		"method" => "drop_array",
		"friendly_name" => "认证区域",
		"description" => "仅在你使用LDAP或Web基本认证时使用.  更改此项为不可用区域将有效禁用用户.",
		"value" => "|arg1:realm|",
		"default" => 0,
		"array" => $auth_realms,
		),
	"id" => array(
		"method" => "hidden_zero",
		"value" => "|arg1:id|"
		),
	"_policy_graphs" => array(
		"method" => "hidden",
		"default" => "2",
		"value" => "|arg1:policy_graphs|"
		),
	"_policy_trees" => array(
		"method" => "hidden",
		"default" => "2",
		"value" => "|arg1:policy_trees|"
		),
	"_policy_hosts" => array(
		"method" => "hidden",
		"default" => "2",
		"value" => "|arg1:policy_hosts|"
		),
	"_policy_graph_templates" => array(
		"method" => "hidden",
		"default" => "2",
		"value" => "|arg1:policy_graph_templates|"
		),
	"save_component_user" => array(
		"method" => "hidden",
		"value" => "1"
		)
	);

$export_types = array(
	"graph_template" => array(
		"name" => "图像模板",
		"title_sql" => "select name from graph_templates where id=|id|",
		"dropdown_sql" => "select id,name from graph_templates order by name"
		),
	"data_template" => array(
		"name" => "数据模板",
		"title_sql" => "select name from data_template where id=|id|",
		"dropdown_sql" => "select id,name from data_template order by name"
		),
	"host_template" => array(
		"name" => "设备模板",
		"title_sql" => "select name from host_template where id=|id|",
		"dropdown_sql" => "select id,name from host_template order by name"
		),
	"data_query" => array(
		"name" => "数据查询",
		"title_sql" => "select name from snmp_query where id=|id|",
		"dropdown_sql" => "select id,name from snmp_query order by name"
		)
	);
?>
