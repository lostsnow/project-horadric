<?php
/*
 +-------------------------------------------------------------------------+
 | Copyright (C) 2004-2009 The Cacti Group                                 |
 |                                                                         |
 | This program is free software; you can redistribute it and/or           |
 | modify it under the terms of the GNU General Public License             |
 | as published by the Free Software Foundation; either version 2          |
 | of the License, or (at your option) any later version.                  |
 |                                                                         |
 | This program is distributed in the hope that it will be useful,         |
 | but WITHOUT ANY WARRANTY; without even the implied warranty of          |
 | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the           |
 | GNU General Public License for more details.                            |
 +-------------------------------------------------------------------------+
 | Cacti: The Complete RRDTool-based Graphing Solution                     |
 +-------------------------------------------------------------------------+
 | This code is designed, written, and maintained by the Cacti Group. See  |
 | about.php and/or the AUTHORS file for specific developer information.   |
 +-------------------------------------------------------------------------+
 | http://www.cacti.net/                                                   |
 +-------------------------------------------------------------------------+
*/

include("./include/auth.php");
include("./include/top_header.php");

html_start_box("<strong>关于Cacti</strong>", "100%", $colors["header"], "3", "center", "");
?>

<tr>
	<td bgcolor="#<?php print $colors["header_panel"];?>" colspan="2">
		<strong><font color="#<?php print $colors["header_text"];?>">版本: <?php print $config["cacti_version"];?></font></strong>
	</td>
</tr>
<tr>
	<td valign="top" bgcolor="#<?php print $colors["light"];?>" class="textArea">
		<a href="http://www.cacti.net/"><img align="right" src="images/cacti_about_logo.gif" border="0" alt="cacti主站"></a>

		Cacti是基于RRDTool框架设计的一个全图像化的解决方案.它的目标是通过获取必要的信息创建有意义的图像来使网络管理者的工作变得更加容易.

		<p>通过查看 <a href="http://www.cacti.net/">Cacti 官方网站</a> 可以获得相关信息,支持以及最新更新.</p>

		<p><strong>当前Cacti的开发者</strong><br>
		<ul type="disc">
			<li><strong>Ian Berry</strong> (raX) 是2001年Cacti第一个发行版的原作者,他在接下来的两年多时间是唯一的开发人员,负责撰写代码,对用户进行支持,并且坚持维护此项目.至今,Ian仍是Cacti的活跃开发人员,主要关注模板,数据查询,图像管理等组件.
			</li>
			<li><strong>Larry Adams</strong> (TheWitness) 于2004年6月主要版本0.8.6发布前加入Cacti团队,他通过提供想法,撰写代码并且管理beta版本的活跃测试小组促成新的poller结构的出现.Larry 关注于RRDTOOl的集成,Windows环境下SNMP以及poller.
			</li>
			<li><strong>Tony Roman</strong> (rony) 于2004年10月加入Cacti团队,对此项目贡献了其多年的编程与系统管理经验,在将发布的0.9版本中,除了修补用户管理组件外，他还在可用性及文档变化中做出了大量的贡献.
			</li>
			<li><strong>J.P. Pasnak, CD</strong> (Linegod) 2005年8月加入Cacti团队. 主要工作在0.9版本中,并且维护Cacti的<a href="http://docs.cacti.net/">文档资料</a>.
			</li>
			<li><strong>Jimmy Conner</strong> (cigamit) 2006年1月加入Cacti团队. 现在主要负责Cacti插件系统结构,新的事件系统及维护众多流行的插件.
			</li>
			<li><strong>Reinhard Scheck</strong> (gandalf) 2007年6月加入Cacti团队. Reinhard关注于Cacti的使用(Howto)及图像表现形式.
			</li>
			<li><strong>Wy Silly</strong> (wysilly) 2006年11月开始维护Cacti中文版本,属于Cacti编外人员.
 			</li>
		</ul>
		</p>

		<p><strong>致敬</a></strong><br>
		<ul type="disc">
			<li>最大的敬意送给<a href="http://tobi.oetiker.ch/"><strong>Tobi Oetiker</strong></a>,
				<a href="http://www.rrdtool.org/">RRDTool</a> 的作者以及非常流行的
				<a href="http://www.rrdtool.org">MRTG</a>.</li>
			<li><strong>Brady Alleman</strong>, NetMRG及
				<a href="http://www.thtech.net">Treehouse Technologies</a> 的问题及概念的作者.值得一提的是NetMRG也是基于php/mysql的一个完整的网络监控方案.他的产品也使用了RRDTOOL的图像功能,建议你了解一下.</li>
			<li><strong>Andy Blyler</strong>, 对冗长的编码会话中的想法,代码及全面的支持.</li>
			<li><strong>Cacti的用户</strong>! 尤其是那些花时间创建bug报告,或者帮助解决Cacti相关问题的人,及从amazon.com明细表购买项目或者为此项目捐赠钱的人.</li>

		</ul>
		</p>

		<p><strong>版权</strong><br>

		<p>Cacti采用GNU GPL许可方式:</p>

		<p><tt>本程式为免费软件,遵从GNU GPL许可方式,既可以采用GPL v2也可以采用更新的版本,你可以重新发布或修改此程序.</tt></p>

<p><tt>本程式的发布是希望对于使用者有所帮助,没有任何授权用于商业或其它特殊用途.详情请看GNU GPL许可授权.</tt></p>

		<p><strong>Cacti全局变量</a></strong><span style="font-family: monospace; font-size: 12px;"><br>
		<strong>操作系统:</strong> <?php print $config["cacti_server_os"];?><br>
		<strong>PHP SNMP支持:</strong> <?php print $config["php_snmp_support"] ? "支持" : "不支持";?><br>
		</span></p>
	</td>
</tr>

<?php
html_end_box();
include("./include/bottom_footer.php");
?>
