<?php
/*
 +-------------------------------------------------------------------------+
 | Copyright (C) 2004-2009 The Cacti Group                                 |
 |                                                                         |
 | This program is free software; you can redistribute it and/or           |
 | modify it under the terms of the GNU General Public License             |
 | as published by the Free Software Foundation; either version 2          |
 | of the License, or (at your option) any later version.                  |
 |                                                                         |
 | This program is distributed in the hope that it will be useful,         |
 | but WITHOUT ANY WARRANTY; without even the implied warranty of          |
 | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the           |
 | GNU General Public License for more details.                            |
 +-------------------------------------------------------------------------+
 | Cacti: The Complete RRDTool-based Graphing Solution                     |
 +-------------------------------------------------------------------------+
 | This code is designed, written, and maintained by the Cacti Group. See  |
 | about.php and/or the AUTHORS file for specific developer information.   |
 +-------------------------------------------------------------------------+
 | http://www.cacti.net/                                                   |
 +-------------------------------------------------------------------------+
*/

include("./include/auth.php");
include_once("./lib/utility.php");

load_current_session_value("page_referrer", "page_referrer", "");

/* set default action */
if (!isset($_REQUEST["action"])) { $_REQUEST["action"] = ""; }

if (isset($_REQUEST["sort_direction"])) {
	if ($_REQUEST['page_referrer'] == "view_snmp_cache") {
		$_REQUEST["action"] = "view_snmp_cache";
	}else if ($_REQUEST['page_referrer'] == "view_poller_cache") {
		$_REQUEST["action"] = "view_poller_cache";
	}else{
		$_REQUEST["action"] = "view_user_log";
	}
}

if ((isset($_REQUEST["clear_x"])) || (isset($_REQUEST["go_x"]))) {
	if ($_REQUEST['page_referrer'] == "view_snmp_cache") {
		$_REQUEST["action"] = "view_snmp_cache";
	}else if ($_REQUEST['page_referrer'] == "view_poller_cache") {
		$_REQUEST["action"] = "view_poller_cache";
	}else if ($_REQUEST['page_referrer'] == "view_user_log") {
		$_REQUEST["action"] = "view_user_log";
	}else{
		$_REQUEST["action"] = "view_logfile";
	}
}

if (isset($_REQUEST["purge_x"])) {
	if ($_REQUEST['page_referrer'] == "view_user_log") {
		$_REQUEST["action"] = "clear_user_log";
	}else{
		$_REQUEST["action"] = "clear_logfile";
	}
}

switch ($_REQUEST["action"]) {
	case 'clear_poller_cache':
		include_once("./include/top_header.php");

		/* obtain timeout settings */
		$max_execution = ini_get("max_execution_time");
		$max_memory = ini_get("memory_limit");

		ini_set("max_execution_time", "0");
		ini_set("memory_limit", "32M");

		repopulate_poller_cache();

		ini_set("max_execution_time", $max_execution);
		ini_set("memory_limit", $max_memory);

		utilities_view_poller_cache();

		include_once("./include/bottom_footer.php");
		break;
	case 'view_snmp_cache':
		include_once("./include/top_header.php");

		utilities_view_snmp_cache();

		include_once("./include/bottom_footer.php");
		break;
	case 'view_poller_cache':
		include_once("./include/top_header.php");

		utilities_view_poller_cache();

		include_once("./include/bottom_footer.php");
		break;
	case 'view_logfile':
		utilities_view_logfile();

		break;
	case 'clear_logfile':
		utilities_clear_logfile();
		utilities_view_logfile();

		include_once("./include/bottom_footer.php");
		break;
	case 'view_user_log':
		include_once("./include/top_header.php");

		utilities_view_user_log();

		include_once("./include/bottom_footer.php");
		break;
	case 'clear_user_log':
		include_once("./include/top_header.php");

		utilities_clear_user_log();
		utilities_view_user_log();

		include_once("./include/bottom_footer.php");
		break;
	case 'view_tech':
		$php_info = utilities_php_modules();

		include_once("./include/top_header.php");

		utilities_view_tech($php_info);

		include_once("./include/bottom_footer.php");
		break;
	default:
		include_once("./include/top_header.php");

		utilities();

		include_once("./include/bottom_footer.php");
		break;
}

/* -----------------------
    Utilities Functions
   ----------------------- */

function utilities_php_modules() {

	/*
	   Gather phpinfo into a string variable - This has to be done before
	   any headers are sent to the browser, as we are going to do some
	   output buffering fun
	*/

	ob_start();
	phpinfo(INFO_MODULES);
	$php_info = ob_get_contents();
	ob_end_clean();

	/* Remove nasty style sheets, links and other junk */
	$php_info = str_replace("\n", "", $php_info);
	$php_info = preg_replace('/^.*\<body\>/', '', $php_info);
	$php_info = preg_replace('/\<\/body\>.*$/', '', $php_info);
	$php_info = preg_replace('/\<a.*\>/U', '', $php_info);
	$php_info = preg_replace('/\<\/a\>/', '<hr>', $php_info);
	$php_info = preg_replace('/\<img.*\>/U', '', $php_info);
	$php_info = preg_replace('/\<\/?address\>/', '', $php_info);

	return $php_info;
}


function memory_bytes($val) {
    $val = trim($val);
    $last = strtolower($val{strlen($val)-1});
    switch($last) {
        // The 'G' modifier is available since PHP 5.1.0
        case 'g':
            $val *= 1024;
        case 'm':
            $val *= 1024;
        case 'k':
            $val *= 1024;
    }

    return $val;
}


function memory_readable($val) {

	if ($val < 1024) {
		$val_label = "bytes";
	}elseif ($val < 1048576) {
		$val_label = "K";
		$val /= 1024;
	}elseif ($val < 1073741824) {
		$val_label = "M";
		$val /= 1048576;
	}else{
		$val_label = "G";
		$val /= 1073741824;
	}

    return $val . $val_label;
}


function utilities_view_tech($php_info = "") {
	global $database_default, $colors, $config, $rrdtool_versions, $poller_options, $input_types;

	/* Get table status */
	$tables = db_fetch_assoc("SHOW TABLES");
	$skip_tables  = array();
	$table_status = array();

	if (sizeof($tables)) {
	foreach($tables as $table) {
		$create_syntax = db_fetch_row("SHOW CREATE TABLE " . $table["Tables_in_" . $database_default]);

		if (sizeof($create_syntax)) {
			if (substr_count(strtoupper($create_syntax["Create Table"]), "INNODB")) {
				$skip_tables[] = $table["Tables_in_" . $database_default];
			}else{
				$include_tables[] = $table["Tables_in_" . $database_default];
			}
		}
	}
	}

	if (sizeof($include_tables)) {
	foreach($include_tables as $table) {
		$status = db_fetch_row("SHOW TABLE STATUS LIKE '$table'");

		array_push($table_status, $status);
	}
	}

	/* Get poller stats */
	$poller_item = db_fetch_assoc("SELECT action, count(action) as total FROM poller_item GROUP BY action");

	/* Get system stats */
	$host_count = db_fetch_cell("SELECT COUNT(*) FROM host");
	$graph_count = db_fetch_cell("SELECT COUNT(*) FROM graph_local");
	$data_count = db_fetch_assoc("SELECT i.type_id, COUNT(i.type_id) AS total FROM data_template_data AS d, data_input AS i WHERE d.data_input_id = i.id AND local_data_id <> 0 GROUP BY i.type_id");

	/* Get RRDtool version */
	$rrdtool_version = "未知";
	if ((file_exists(read_config_option("path_rrdtool"))) && ((function_exists('is_executable')) && (is_executable(read_config_option("path_rrdtool"))))) {

		$out_array = array();
		exec(read_config_option("path_rrdtool"), $out_array);

		if (sizeof($out_array) > 0) {
			if (ereg("^RRDtool 1\.3", $out_array[0])) {
				$rrdtool_version = "rrd-1.3.x";
			}else if (ereg("^RRDtool 1\.2\.", $out_array[0])) {
				$rrdtool_version = "rrd-1.2.x";
			}else if (ereg("^RRDtool 1\.0\.", $out_array[0])) {
				$rrdtool_version = "rrd-1.0.x";
			}
		}
	}

	/* Get SNMP cli version */
	$snmp_version = read_config_option("snmp_version");
	if ((file_exists(read_config_option("path_snmpget"))) && ((function_exists('is_executable')) && (is_executable(read_config_option("path_snmpget"))))) {
		$snmp_version = shell_exec(read_config_option("path_snmpget") . " -V 2>&1");
	}

	/* Check RRDTool issues */
	$rrdtool_error = "";
	if ($rrdtool_version != read_config_option("rrdtool_version")) {
		$rrdtool_error .= "<br><font color='red'>错误: 安装的RRDTool版本与配置的不符.<br>请点击<a href='settings.php?tab=general'>设置</a>选择正确的RRDTool应用程序版本.</font><br>";
	}
	$graph_gif_count = db_fetch_cell("SELECT COUNT(*) FROM graph_templates_graph WHERE image_format_id = 2");
	if (($graph_gif_count > 0) && (read_config_option("rrdtool_version") != "rrd-1.0.x")) {
		$rrdtool_error .= "<br><font color='red'>错误: RRDTool 1.2.x版本不支持GIF图像格式, 但是有" . $graph_gif_count . "个图像和/或模板设置了GIF图像格式.</font><br>";
	}

	/* Display tech information */
	html_start_box("<strong>技术支持</strong>", "100%", $colors["header"], "3", "center", "");
	html_header(array("常规信息"), 2);
	print "<tr bgcolor='" . $colors["form_alternate1"] . "'>\n";
	print "		<td class='textArea'>日期</td>\n";
	print "		<td class='textArea'>" . date("r") . "</td>\n";
	print "</tr>\n";
	print "<tr bgcolor='" . $colors["form_alternate2"] . "'>\n";
	print "		<td class='textArea'>Cacti版本</td>\n";
	print "		<td class='textArea'>" . $config["cacti_version"] . "</td>\n";
	print "</tr>\n";
	print "<tr bgcolor='" . $colors["form_alternate1"] . "'>\n";
	print "		<td class='textArea'>Cacti系统平台</td>\n";
	print "		<td class='textArea'>" . $config["cacti_server_os"] . "</td>\n";
	print "</tr>\n";
	print "<tr bgcolor='" . $colors["form_alternate2"] . "'>\n";
	print "		<td class='textArea'>SNMP版本</td>\n";
	print "		<td class='textArea'>" . $snmp_version . "</td>\n";
	print "</tr>\n";

	print "<tr bgcolor='" . $colors["form_alternate1"] . "'>\n";
	print "		<td class='textArea'>RRDTool版本</td>\n";
	print "		<td class='textArea'>" . $rrdtool_versions[$rrdtool_version] . " " . $rrdtool_error . "</td>\n";
	print "</tr>\n";
	print "<tr bgcolor='" . $colors["form_alternate2"] . "'>\n";
	print "		<td class='textArea'>设备</td>\n";
	print "		<td class='textArea'>" . $host_count . "</td>\n";
	print "</tr>\n";
	print "<tr bgcolor='" . $colors["form_alternate1"] . "'>\n";
	print "		<td class='textArea'>图像</td>\n";
	print "		<td class='textArea'>" . $graph_count . "</td>\n";
	print "</tr>\n";
	print "<tr bgcolor='" . $colors["form_alternate2"] . "'>\n";
	print "		<td class='textArea'>数据源</td>\n";
	print "		<td class='textArea'>";
	$data_total = 0;
	if (sizeof($data_count)) {
		foreach ($data_count as $item) {
			print $input_types[$item["type_id"]] . ": " . $item["total"] . "<br>";
			$data_total += $item["total"];
		}
		print "总计: " . $data_total;
	}else{
		print "<font color='red'>0</font>";
	}
	print "</td>\n";
	print "</tr>\n";

	html_header(array("轮询器信息"), 2);
	print "<tr bgcolor='" . $colors["form_alternate1"] . "'>\n";
	print "		<td class='textArea'>时间间歇</td>\n";
	print "		<td class='textArea'>" . read_config_option("poller_interval") . "</td>\n";
	print "</tr>\n";
	print "<tr bgcolor='" . $colors["form_alternate2"] . "'>\n";
	print "		<td class='textArea'>类型</td>\n";
	print "		<td class='textArea'>" . $poller_options[read_config_option("poller_type")] . "</td>\n";
	print "</tr>\n";
	print "<tr bgcolor='" . $colors["form_alternate1"] . "'>\n";
	print "		<td class='textArea'>项目</td>\n";
	print "		<td class='textArea'>";
	$total = 0;
	if (sizeof($poller_item)) {
		foreach ($poller_item as $item) {
			print "操作[" . $item["action"] . "]: " . $item["total"] . "<br>";
			$total += $item["total"];
		}
		print "总计: " . $total;
	}else{
		print "<font color='red'>无轮询项目</font>";
	}
	print "</td>\n";
	print "</tr>\n";

	print "<tr bgcolor='" . $colors["form_alternate2"] . "'>\n";
	print "		<td class='textArea'>并发进程</td>\n";
	print "		<td class='textArea'>" . read_config_option("concurrent_processes") . "</td>\n";
	print "</tr>\n";

	print "<tr bgcolor='" . $colors["form_alternate1"] . "'>\n";
	print "		<td class='textArea'>最大线程</td>\n";
	print "		<td class='textArea'>" . read_config_option("max_threads") . "</td>\n";
	print "</tr>\n";

	print "<tr bgcolor='" . $colors["form_alternate2"] . "'>\n";
	print "		<td class='textArea'>PHP服务程序</td>\n";
	print "		<td class='textArea'>" . read_config_option("php_servers") . "</td>\n";
	print "</tr>\n";

	print "<tr bgcolor='" . $colors["form_alternate1"] . "'>\n";
	print "		<td class='textArea'>脚本超时</td>\n";
	print "		<td class='textArea'>" . read_config_option("script_timeout") . "</td>\n";
	print "</tr>\n";

	print "<tr bgcolor='" . $colors["form_alternate2"] . "'>\n";
	print "		<td class='textArea'>最大OID</td>\n";
	print "		<td class='textArea'>" . read_config_option("max_get_size") . "</td>\n";
	print "</tr>\n";


	print "<tr bgcolor='" . $colors["form_alternate1"] . "'>\n";
	print "		<td class='textArea'>上次运行统计信息</td>\n";
	print "		<td class='textArea'>" . read_config_option("stats_poller") . "</td>\n";
	print "</tr>\n";


	html_header(array("PHP信息"), 2);
	print "<tr bgcolor='" . $colors["form_alternate1"] . "'>\n";
	print "		<td class='textArea'>PHP版本</td>\n";
	print "		<td class='textArea'>" . phpversion() . "</td>\n";
	print "</tr>\n";
	print "<tr bgcolor='" . $colors["form_alternate2"] . "'>\n";
	print "		<td class='textArea'>PHP系统平台</td>\n";
	print "		<td class='textArea'>" . PHP_OS . "</td>\n";
	print "</tr>\n";
	print "<tr bgcolor='" . $colors["form_alternate1"] . "'>\n";
	print "		<td class='textArea'>PHP系统平台信息</td>\n";
	print "		<td class='textArea'>";
	if (function_exists("php_uname")) {
		print php_uname();
	}else{
		print "N/A";
	}
	print "</td>\n";
	print "</tr>\n";
	print "<tr bgcolor='" . $colors["form_alternate2"] . "'>\n";
	print "		<td class='textArea'>PHP SNMP</td>\n";
	print "		<td class='textArea'>";
	if (function_exists("snmpget")) {
		print "已安装";
	} else {
		print "未安装";
	}
	print "</td>\n";
	print "</tr>\n";
	print "<tr bgcolor='" . $colors["form_alternate1"] . "'>\n";
	print "		<td class='textArea'>最大运行时间</td>\n";
	print "		<td class='textArea'>" . ini_get("max_execution_time") . "</td>\n";
	print "</tr>\n";
	print "<tr bgcolor='" . $colors["form_alternate2"] . "'>\n";
	print "		<td class='textArea'>内存限制</td>\n";
	print "		<td class='textArea'>" . ini_get("memory_limit");

	/* Calculate memory suggestion based off of data source count */
	$memory_suggestion = $data_total * 32768;
	/* Set minimum - 16M */
	if ($memory_suggestion < 16777216) {
		$memory_suggestion = 16777216;
	}
	/* Set maximum - 512M */
	if ($memory_suggestion > 536870912) {
		$memory_suggestion = 536870912;
	}
	/* Suggest values in 8M increments */
	$memory_suggestion = round($memory_suggestion / 8388608) * 8388608;
	if (memory_bytes(ini_get('memory_limit')) < $memory_suggestion) {
		print "<br><font color='red'>强烈建议你更改php.ini中的memory_limit为" . memory_readable($memory_suggestion) . "或更高.  此内存值是基于当前数据源的数目计算而得,仅是建议值,实际值根据需求在不同的系统中可能不同.</font><br>";
	}
	print "</td>\n";
	print "</tr>\n";

	html_header(array("MySQL表信息"), 2);
	print "<tr bgcolor='" . $colors["form_alternate1"] . "'>\n";
	print "		<td class='textArea' colspan='2' align='center'>";
	if (sizeof($table_status) > 0) {
		print "<table border='1' cellpadding='2' cellspacing='0'>\n";
		print "<tr>\n";
		print "  <th>表名</th>\n";
		print "  <th>行数</th>\n";
		print "  <th>存储引擎</th>\n";
		print "  <th>字符集对照</th>\n";
		print "  <th>检查状态</th>\n";
		print "</tr>\n";
		foreach ($table_status as $item) {
			print "<tr>\n";
			print "  <td>" . $item["Name"] . "</td>\n";
			print "  <td>" . $item["Rows"] . "</td>\n";
			if (isset($item["Engine"])) {
				print "  <td>" . $item["Engine"] . "</td>\n";
			}else{
				print "  <td>未知</td>\n";
			}
			if (isset($item["Collation"])) {
				print "  <td>" . $item["Collation"] . "</td>\n";
			} else {
				print "  <td>未知</td>\n";
			}
			print "  <td>" . db_fetch_cell("CHECK TABLE " . $item["Name"], "Msg_text") . "</td>\n";
			print "</tr>\n";
		}

		if (sizeof($skip_tables)) {
			print "<tr><td colspan='20' align='center'><strong>跳过下列INNODB表</strong></td></tr>";

			foreach($skip_tables as $table) {
				print "<tr><td colspan='20' align='center'>" . $table . "</td></tr>";
			}
		}

		print "</table>\n";
	}else{
		print "未能检索表状态";
	}

	print "</td>\n";
	print "</tr>\n";

	html_header(array("PHP模块信息"), 2);
	print "<tr bgcolor='" . $colors["form_alternate1"] . "'>\n";
	print "		<td class='textArea' colspan='2'>" . $php_info . "</td>\n";
	print "</tr>\n";

	html_end_box();

}


function utilities_view_user_log() {
	global $colors, $auth_realms;

	define("MAX_DISPLAY_PAGES", 21);

	/* ================= input validation ================= */
	input_validate_input_number(get_request_var_request("result"));
	input_validate_input_number(get_request_var_request("page"));
	/* ==================================================== */

	/* clean up username */
	if (isset($_REQUEST["username"])) {
		$_REQUEST["username"] = sanitize_search_string(get_request_var("username"));
	}

	/* clean up search filter */
	if (isset($_REQUEST["filter"])) {
		$_REQUEST["filter"] = sanitize_search_string(get_request_var("filter"));
	}

	/* clean up sort_column */
	if (isset($_REQUEST["sort_column"])) {
		$_REQUEST["sort_column"] = sanitize_search_string(get_request_var("sort_column"));
	}

	/* clean up sort direction */
	if (isset($_REQUEST["sort_direction"])) {
		$_REQUEST["sort_direction"] = sanitize_search_string(get_request_var("sort_direction"));
	}

	/* if the user pushed the 'clear' button */
	if (isset($_REQUEST["clear_x"])) {
		kill_session_var("sess_userlog_current_page");
		kill_session_var("sess_userlog_username");
		kill_session_var("sess_userlog_result");
		kill_session_var("sess_userlog_filter");
		kill_session_var("sess_userlog_sort_column");
		kill_session_var("sess_userlog_sort_direction");

		unset($_REQUEST["page"]);
		unset($_REQUEST["result"]);
		unset($_REQUEST["filter"]);
		unset($_REQUEST["username"]);
		unset($_REQUEST["sort_column"]);
		unset($_REQUEST["sort_direction"]);
	}

	/* remember these search fields in session vars so we don't have to keep passing them around */
	load_current_session_value("page", "sess_userlog_current_page", "1");
	load_current_session_value("username", "sess_userlog_username", "-1");
	load_current_session_value("result", "sess_userlog_result", "-1");
	load_current_session_value("filter", "sess_userlog_filter", "");
	load_current_session_value("sort_column", "sess_userlog_sort_column", "time");
	load_current_session_value("sort_direction", "sess_userlog_sort_direction", "DESC");

	$_REQUEST['page_referrer'] = 'view_user_log';
	load_current_session_value('page_referrer', 'page_referrer', 'view_user_log');

	?>
	<script type="text/javascript">
	<!--

	function applyViewLogFilterChange(objForm) {
		strURL = '?username=' + objForm.username.value;
		strURL = strURL + '&result=' + objForm.result.value;
		strURL = strURL + '&action=view_user_log';
		document.location = strURL;
	}

	-->
	</script>
	<?php

	html_start_box("<strong>用户登录历史</strong>", "100%", $colors["header"], "3", "center", "");

	?>
	<tr bgcolor="<?php print $colors["panel"];?>">
		<form name="form_userlog">
		<td>
			<table cellpadding="0" cellspacing="0">
				<tr>
					<td nowrap style='white-space: nowrap;' width="55">
						&nbsp;<strong>用户名:</strong>&nbsp;
					</td>
					<td width="1">
						<select name="username" onChange="applyViewLogFilterChange(document.form_userlog)">
							<option value="-1"<?php if (get_request_var_request("username") == "-1") {?> selected<?php }?>>所有</option>
							<option value="-2"<?php if (get_request_var_request("username") == "-2") {?> selected<?php }?>>已删/无效</option>
							<?php
							$users = db_fetch_assoc("SELECT DISTINCT username FROM user_auth ORDER BY username");

							if (sizeof($users) > 0) {
							foreach ($users as $user) {
								print "<option value='" . $user["username"] . "'"; if (get_request_var_request("username") == $user["username"]) { print " selected"; } print ">" . $user["username"] . "</option>\n";
							}
							}
							?>
						</select>
					</td>
					<td nowrap style='white-space: nowrap;' width="40">
						&nbsp;<strong>结果:</strong>&nbsp;
					</td>
					<td width="1">
						<select name="result" onChange="applyViewLogFilterChange(document.form_userlog)">
							<option value="-1"<?php if (get_request_var_request("result") == '-1') {?> selected<?php }?>>所有</option>
							<option value="1"<?php if (get_request_var_request("result") == '1') {?> selected<?php }?>>成功</option>
							<option value="0"<?php if (get_request_var_request("result") == '0') {?> selected<?php }?>>失败</option>
						</select>
					</td>
					<td nowrap style='white-space: nowrap;' width="40">
						&nbsp;<strong>搜索:<strong>&nbsp;
					</td>
					<td width="1">
						<input type="text" name="filter" size="20" value="<?php print get_request_var_request("filter");?>">
					</td>
					<td nowrap style='white-space: nowrap;'>
						&nbsp;<input type="image" src="images/button_go.gif" name="go" alt="确认" border="0" align="absmiddle">
						<input type="image" src="images/button_clear.gif" name="clear" alt="清除" border="0" align="absmiddle">
						<input type="image" src="images/button_purge.gif" name="purge" alt="清理" border="0" align="absmiddle">
					</td>
				</tr>
			</table>
		</td>
		<input type='hidden' name='page' value='1'>
		<input type='hidden' name='action' value='view_user_log'>
		</form>
	</tr>
	<?php

	html_end_box();

	$sql_where = "";

	/* filter by username */
	if (get_request_var_request("username") == "-2") {
		$sql_where = "WHERE user_log.username NOT IN (SELECT DISTINCT username from user_auth)";
	}elseif (get_request_var_request("username") != "-1") {
		$sql_where = "WHERE user_log.username='" . get_request_var_request("username") . "'";
	}

	/* filter by result */
	if (get_request_var_request("result") != "-1") {
		if (strlen($sql_where)) {
			$sql_where .= " AND user_log.result=" . get_request_var_request("result");
		}else{
			$sql_where = "WHERE user_log.result=" . get_request_var_request("result");
		}
	}

	/* filter by search string */
	if (get_request_var_request("filter") <> "") {
		if (strlen($sql_where)) {
			$sql_where .= " AND (user_log.username LIKE '%%" . get_request_var_request("filter") . "%%'
				OR user_log.time LIKE '%%" . get_request_var_request("filter") . "%%'
				OR user_log.ip LIKE '%%" . get_request_var_request("filter") . "%%')";
		}else{
			$sql_where = "WHERE (user_log.username LIKE '%%" . get_request_var_request("filter") . "%%'
				OR user_log.time LIKE '%%" . get_request_var_request("filter") . "%%'
				OR user_log.ip LIKE '%%" . get_request_var_request("filter") . "%%')";
		}
	}

	html_start_box("", "100%", $colors["header"], "3", "center", "");

	$total_rows = db_fetch_cell("SELECT
		COUNT(*)
		FROM user_auth
		RIGHT JOIN user_log
		ON user_auth.username = user_log.username
		$sql_where");

	$user_log_sql = "SELECT
		user_log.username,
		user_auth.full_name,
		user_auth.realm,
		user_log.time,
		user_log.result,
		user_log.ip
		FROM user_auth
		RIGHT JOIN user_log
		ON user_auth.username = user_log.username
		$sql_where
		ORDER BY " . get_request_var_request("sort_column") . " " . get_request_var_request("sort_direction") . "
		LIMIT " . (read_config_option("num_rows_data_source")*(get_request_var_request("page")-1)) . "," . read_config_option("num_rows_data_source");

//	print $user_log_sql;

	$user_log = db_fetch_assoc($user_log_sql);

	/* generate page list */
	$url_page_select = get_page_list(get_request_var_request("page"), MAX_DISPLAY_PAGES, read_config_option("num_rows_data_source"), $total_rows, "utilities.php?action=view_user_log&username=" . get_request_var_request("username") . "&filter=" . get_request_var_request("filter"));

	$nav = "<tr bgcolor='#" . $colors["header"] . "'>
			<td colspan='7'>
				<table width='100%' cellspacing='0' cellpadding='0' border='0'>
					<tr>
						<td align='left' class='textHeaderDark'>
							<strong>&lt;&lt; "; if (get_request_var_request("page") > 1) { $nav .= "<a class='linkOverDark' href='utilities.php?action=view_user_log&username=" . get_request_var_request("username") . "&filter=" . get_request_var_request("filter") . "&page=" . (get_request_var_request("page")-1) . "'>"; } $nav .= "上一页"; if (get_request_var_request("page") > 1) { $nav .= "</a>"; } $nav .= "</strong>
						</td>\n
						<td align='center' class='textHeaderDark'>
							显示行 " . ((read_config_option("num_rows_data_source")*(get_request_var_request("page")-1))+1) . " 至 " . ((($total_rows < read_config_option("num_rows_data_source")) || ($total_rows < (read_config_option("num_rows_data_source")*get_request_var_request("page")))) ? $total_rows : (read_config_option("num_rows_data_source")*get_request_var_request("page"))) . " 共 $total_rows [$url_page_select]
						</td>\n
						<td align='right' class='textHeaderDark'>
							<strong>"; if ((get_request_var_request("page") * read_config_option("num_rows_data_source")) < $total_rows) { $nav .= "<a class='linkOverDark' href='utilities.php?action=view_user_log&username=" . get_request_var_request("username") . "&filter=" . get_request_var_request("filter") . "&page=" . (get_request_var_request("page")+1) . "'>"; } $nav .= "下一页"; if ((get_request_var_request("page") * read_config_option("num_rows_data_source")) < $total_rows) { $nav .= "</a>"; } $nav .= " &gt;&gt;</strong>
						</td>\n
					</tr>
				</table>
			</td>
		</tr>\n";

	print $nav;

	$display_text = array(
		"username" => array("用户名", "ASC"),
		"full_name" => array("全名", "ASC"),
		"realm" => array("认证区域", "ASC"),
		"time" => array("日期", "ASC"),
		"result" => array("结果", "DESC"),
		"ip" => array("IP地址", "DESC"));

	html_header_sort($display_text, get_request_var_request("sort_column"), get_request_var_request("sort_direction"));

	$i = 0;
	if (empty($_REQUEST["filter"])|| !isset($_REQUEST["filter"])) $_REQUEST["filter"]=".*";
	if (sizeof($user_log) > 0) {
		foreach ($user_log as $item) {
			if (isset($item["full_name"])) {
				form_alternate_row_color($colors["form_alternate1"],$colors["form_alternate2"],$i);
			}else{
				form_alternate_row_color("FF9D9D","FFAFAF",$i);
			}
			?>
			<td width='35%'>
				<?php print (strlen(get_request_var_request("filter")) ? (eregi_replace("(" . preg_quote(get_request_var_request("filter")) . ")", "<span style='background-color: #F8D93D;'>\\1</span>", $item["username"])) : $item["username"]);?>
			</td>
			<td width='20%'>
				<?php if (isset($item["full_name"])) {
						print (strlen(get_request_var_request("filter")) ? (eregi_replace("(" . preg_quote(get_request_var_request("filter")) . ")", "<span style='background-color: #F8D93D;'>\\1</span>", $item["full_name"])) : $item["full_name"]);
					}else{
						print "(用户已删除)";
					}
				?>
			</td>
			<td width='20%'>
				<?php if (isset($auth_realms[$item["realm"]])) {
						print (strlen(get_request_var_request("filter")) ? (eregi_replace("(" . preg_quote(get_request_var_request("filter")) . ")", "<span style='background-color: #F8D93D;'>\\1</span>", $auth_realms[$item["realm"]])) : $auth_realms[$item["realm"]]);
					}else{
						print "N/A";
					}
				?>
			</td>
			<td width='20%'>
				<?php print (strlen(get_request_var_request("filter")) ? (eregi_replace("(" . preg_quote(get_request_var_request("filter")) . ")", "<span style='background-color: #F8D93D;'>\\1</span>", $item["time"])) : $item["time"]);?>
			</td>
			<td width='10%'>
				<?php print $item["result"] == 0 ? "失败" : "成功";?>
			</td>
			<td width='15%'>
				<?php print (strlen(get_request_var_request("filter")) ? (eregi_replace("(" . preg_quote(get_request_var_request("filter")) . ")", "<span style='background-color: #F8D93D;'>\\1</span>", $item["ip"])) : $item["ip"]);?>
			</td>
			</tr>
			<?php
			$i++;
		}
	}

	html_end_box();
}

function utilities_clear_user_log() {
	$users = db_fetch_assoc("SELECT DISTINCT username FROM user_auth");

	if (sizeof($users)) {
		/* remove active users */
		foreach ($users as $user) {
			$total_rows = db_fetch_cell("SELECT COUNT(username) FROM user_log WHERE username = '" . $user['username'] . "' AND result = 1");
			if ($total_rows > 1) {
				db_execute("DELETE FROM user_log WHERE username = '" . $user['username'] . "' AND result = 1 ORDER BY time LIMIT " . ($total_rows - 1));
			}
			db_execute("DELETE FROM user_log WHERE username = '" . $user['username'] . "' AND result = 0");
		}

		/* delete inactive users */
		db_execute("DELETE FROM user_log WHERE user_id NOT IN (SELECT id FROM user_auth) OR username NOT IN (SELECT username FROM user_auth)");

	}
}

function utilities_view_logfile() {
	global $colors, $log_tail_lines, $page_refresh_interval;

	$logfile = read_config_option("path_cactilog");

	if ($logfile == "") {
		$logfile = "./log/rrd.log";
	}

	/* helps determine output color */
	$linecolor = True;

	input_validate_input_number(get_request_var_request("tail_files"));
	input_validate_input_number(get_request_var_request("message_type"));
	input_validate_input_number(get_request_var_request("refresh"));
	input_validate_input_number(get_request_var_request("reverse"));

	/* if the user pushed the 'clear' button */
	if (isset($_REQUEST["clear_x"])) {
		kill_session_var("sess_logfile_tail_lines");
		kill_session_var("sess_logfile_message_type");
		kill_session_var("sess_logfile_filter");
		kill_session_var("sess_logfile_refresh");
		kill_session_var("sess_logfile_reverse");

		unset($_REQUEST["tail_lines"]);
		unset($_REQUEST["message_type"]);
		unset($_REQUEST["filter"]);
		unset($_REQUEST["refresh"]);
		unset($_REQUEST["reverse"]);
	}

	load_current_session_value("tail_lines", "sess_logfile_tail_lines", read_config_option("num_rows_log"));
	load_current_session_value("message_type", "sess_logfile_message_type", "-1");
	load_current_session_value("filter", "sess_logfile_filter", "");
	load_current_session_value("refresh", "sess_logfile_refresh", read_config_option("log_refresh_interval"));
	load_current_session_value("reverse", "sess_logfile_reverse", 1);

	$_REQUEST['page_referrer'] = 'view_logfile';
	load_current_session_value('page_referrer', 'page_referrer', 'view_logfile');

	$refresh["seconds"] = get_request_var_request("refresh");
	$refresh["page"] = "utilities.php?action=view_logfile";

	include_once("./include/top_header.php");

	?>
	<script type="text/javascript">
	<!--

	function applyViewLogFilterChange(objForm) {
		strURL = '?tail_lines=' + objForm.tail_lines.value;
		strURL = strURL + '&message_type=' + objForm.message_type.value;
		strURL = strURL + '&refresh=' + objForm.refresh.value;
		strURL = strURL + '&reverse=' + objForm.reverse.value;
		strURL = strURL + '&filter=' + objForm.filter.value;
		strURL = strURL + '&action=view_logfile';
		document.location = strURL;
	}

	-->
	</script>
	<?php

	html_start_box("<strong>日志文件过滤</strong>", "100%", $colors["header"], "3", "center", "");

	?>
	<tr bgcolor="<?php print $colors["panel"];?>">
		<form name="form_logfile">
		<td>
			<table cellpadding="1" cellspacing="0">
				<tr>
					<td nowrap style='white-space: nowrap;' width="55">
						&nbsp;<strong>尾行数:</strong>&nbsp;
					</td>
					<td width="1">
						<select name="tail_lines" onChange="applyViewLogFilterChange(document.form_logfile)">
							<?php
							foreach($log_tail_lines AS $tail_lines => $display_text) {
								print "<option value='" . $tail_lines . "'"; if (get_request_var_request("tail_lines") == $tail_lines) { print " selected"; } print ">" . $display_text . "</option>\n";
							}
							?>
						</select>
					</td>
					<td nowrap style='white-space: nowrap;' width="65">
						&nbsp;<strong>信息类型:</strong>&nbsp;
					</td>
					<td width="1">
						<select name="message_type" onChange="applyViewLogFilterChange(document.form_logfile)">
							<option value="-1"<?php if (get_request_var_request("message_type") == '-1') {?> selected<?php }?>>所有</option>
							<option value="1"<?php if (get_request_var_request("message_type") == '1') {?> selected<?php }?>>状态</option>
							<option value="2"<?php if (get_request_var_request("message_type") == '2') {?> selected<?php }?>>警告</option>
							<option value="3"<?php if (get_request_var_request("message_type") == '3') {?> selected<?php }?>>错误</option>
							<option value="4"<?php if (get_request_var_request("message_type") == '4') {?> selected<?php }?>>调试</option>
							<option value="5"<?php if (get_request_var_request("message_type") == '5') {?> selected<?php }?>>SQL调用</option>
						</select>
					</td>
					<td nowrap style='white-space: nowrap;'>
						&nbsp;<input type="image" src="images/button_go.gif" name="go" alt="确认" border="0" align="absmiddle">
						<input type="image" src="images/button_clear.gif" name="clear" alt="清除" border="0" align="absmiddle">
						<input type="image" src="images/button_purge.gif" name="purge" alt="清理" border="0" align="absmiddle">
					</td>
				</tr>
				<tr>
					<td nowrap style='white-space: nowrap;' width="40">
						&nbsp;<strong>刷新:</strong>&nbsp;
					</td>
					<td width="1">
						<select name="refresh" onChange="applyViewLogFilterChange(document.form_logfile)">
							<?php
							foreach($page_refresh_interval AS $seconds => $display_text) {
								print "<option value='" . $seconds . "'"; if (get_request_var_request("refresh") == $seconds) { print " selected"; } print ">" . $display_text . "</option>\n";
							}
							?>
						</select>
					</td>
					<td nowrap style='white-space: nowrap;' width="65">
						&nbsp;<strong>显示顺序:</strong>&nbsp;
					</td>
					<td width="1">
						<select name="reverse" onChange="applyViewLogFilterChange(document.form_logfile)">
							<option value="1"<?php if (get_request_var_request("reverse") == '1') {?> selected<?php }?>>最新优先</option>
							<option value="2"<?php if (get_request_var_request("reverse") == '2') {?> selected<?php }?>>最早优先</option>
						</select>
					</td>
				</tr>
			</table>
			<table cellpadding="1" cellspacing="0">
				<tr>
					<td nowrap style='white-space: nowrap;' width="55">
						&nbsp;<strong>搜索:</strong>&nbsp;
					</td>
					<td width="1">
						<input type="text" name="filter" size="75" value="<?php print get_request_var_request("filter");?>">
					</td>
				</tr>
			</table>
		</td>
		<input type='hidden' name='page' value='1'>
		<input type='hidden' name='action' value='view_logfile'>
		</form>
	</tr>
	<?php

	html_end_box();

	/* read logfile into an array and display */
	$logcontents = tail_file($logfile, get_request_var_request("tail_lines"), get_request_var_request("message_type"), get_request_var_request("filter"));

	if (get_request_var_request("reverse") == 1) {
		$logcontents = array_reverse($logcontents);
	}

	if (get_request_var_request("message_type") > 0) {
		$start_string = "<strong>日志文件</strong> [总行数: " . sizeof($logcontents) . " - 不匹配项目被隐藏]";
	}else{
		$start_string = "<strong>日志文件</strong> [总行数: " . sizeof($logcontents) . " - 所有项目被显示]";
	}

	html_start_box($start_string, "100%", $colors["header"], "3", "center", "");

	$i = 0;
	$j = 0;
	$linecolor = false;
	foreach ($logcontents as $item) {
		$host_start = strpos($item, "Host[");
		$ds_start   = strpos($item, "DS[");

		$new_item = "";

		if ((!$host_start) && (!$ds_start)) {
			$new_item = $item;
		}else{
			while ($host_start) {
				$host_end   = strpos($item, "]", $host_start);
				$host_id    = substr($item, $host_start+5, $host_end-($host_start+5));
				$new_item   = $new_item . substr($item, 0, $host_start + 5) . "<a href='host.php?action=edit&id=" . $host_id . "'>" . substr($item, $host_start + 5, $host_end-($host_start + 5)) . "</a>";
				$item       = substr($item, $host_end);
				$host_start = strpos($item, "Host[");
			}

			$ds_start = strpos($item, "DS[");
			while ($ds_start) {
				$ds_end   = strpos($item, "]", $ds_start);
				$ds_id    = substr($item, $ds_start+3, $ds_end-($ds_start+3));
				$new_item = $new_item . substr($item, 0, $ds_start + 3) . "<a href='data_sources.php?action=ds_edit&id=" . $ds_id . "'>" . substr($item, $ds_start + 3, $ds_end-($ds_start + 3)) . "</a>";
				$item     = substr($item, $ds_end);
				$ds_start = strpos($item, "DS[");
			}

			$new_item = $new_item . $item;
		}

		/* get the background color */
		if ((substr_count($new_item, "ERROR")) || (substr_count($new_item, "FATAL"))) {
			$bgcolor = "FF3932";
		}elseif (substr_count($new_item, "WARN")) {
			$bgcolor = "EACC00";
		}elseif (substr_count($new_item, " SQL ")) {
			$bgcolor = "6DC8FE";
		}elseif (substr_count($new_item, "DEBUG")) {
			$bgcolor = "C4FD3D";
		}elseif (substr_count($new_item, "STATS")) {
			$bgcolor = "96E78A";
		}else{
			if ($linecolor) {
				$bgcolor = "CCCCCC";
			}else{
				$bgcolor = "FFFFFF";
			}
			$linecolor = !$linecolor;
		}

		?>
		<tr bgcolor='#<?php print $bgcolor;?>'>
			<td>
				<?php print $new_item;?>
			</td>
		</tr>
		<?php
		$j++;
		$i++;

		if ($j > 1000) {
			?>
			<tr bgcolor='#EACC00'>
				<td>
					<?php print ">>>>  到达1000行的行限制!!  <<<<";?>
				</td>
			</tr>
			<?php

			break;
		}
	}

	html_end_box();

	include_once("./include/bottom_footer.php");
}

function utilities_clear_logfile() {
	global $colors;

	load_current_session_value("refresh", "sess_logfile_refresh", read_config_option("log_refresh_interval"));

	$refresh["seconds"] = get_request_var_request("refresh");
	$refresh["page"] = "utilities.php?action=view_logfile";

	include_once("./include/top_header.php");

	$logfile = read_config_option("path_cactilog");

	if ($logfile == "") {
		$logfile = "./log/cacti.log";
	}

	html_start_box("<strong>清除Cacti日志文件</strong>", "100%", $colors["header"], "1", "center", "");
	if (file_exists($logfile)) {
		if (is_writable($logfile)) {
			$timestamp = date("m/d/Y h:i:s A");
			$log_fh = fopen($logfile, "w");
			fwrite($log_fh, $timestamp . " - WEBUI: Cacti Log Cleared from Web Management Interface\n");
			fclose($log_fh);
			print "<tr><td>Cacti日志文件已清除</td></tr>";
		}else{
			print "<tr><td><font color='red'><b>错误: 未能清除日志,没有写权限.<b></font></td></tr>";
		}
	}else{
		print "<tr><td><font color='red'><b>错误: 未能清除日志, 文件不存在.</b></font></td></tr>";
	}
	html_end_box();
}

function utilities_view_snmp_cache() {
	global $colors, $poller_actions;

	define("MAX_DISPLAY_PAGES", 21);

	/* ================= input validation ================= */
	input_validate_input_number(get_request_var_request("host_id"));
	input_validate_input_number(get_request_var_request("snmp_query_id"));
	input_validate_input_number(get_request_var_request("page"));
	input_validate_input_number(get_request_var_request("poller_action"));
	/* ==================================================== */

	/* clean up search filter */
	if (isset($_REQUEST["filter"])) {
		$_REQUEST["filter"] = sanitize_search_string(get_request_var("filter"));
	}

	/* if the user pushed the 'clear' button */
	if (isset($_REQUEST["clear_x"])) {
		kill_session_var("sess_snmp_current_page");
		kill_session_var("sess_snmp_host_id");
		kill_session_var("sess_snmp_snmp_query_id");
		kill_session_var("sess_snmp_filter");

		unset($_REQUEST["page"]);
		unset($_REQUEST["filter"]);
		unset($_REQUEST["host_id"]);
		unset($_REQUEST["snmp_query_id"]);
	}

	/* remember these search fields in session vars so we don't have to keep passing them around */
	load_current_session_value("page", "sess_snmp_current_page", "1");
	load_current_session_value("host_id", "sess_snmp_host_id", "-1");
	load_current_session_value("snmp_query_id", "sess_snmp_snmp_query_id", "-1");
	load_current_session_value("filter", "sess_snmp_filter", "");

	$_REQUEST['page_referrer'] = 'view_snmp_cache';
	load_current_session_value('page_referrer', 'page_referrer', 'view_snmp_cache');

	?>
	<script type="text/javascript">
	<!--

	function applyViewSNMPFilterChange(objForm) {
		strURL = '?host_id=' + objForm.host_id.value;
		strURL = strURL + '&snmp_query_id=' + objForm.snmp_query_id.value;
		strURL = strURL + '&filter=' + objForm.filter.value;
		strURL = strURL + '&action=view_snmp_cache';
		document.location = strURL;
	}

	-->
	</script>
	<?php

	html_start_box("<strong>SNMP缓存项目</strong>", "100%", $colors["header"], "3", "center", "");

	?>
	<tr bgcolor="<?php print $colors["panel"];?>">
		<form name="form_snmpcache">
		<td>
			<table cellpadding="0" cellspacing="0">
				<tr>
					<td nowrap style='white-space: nowrap;' width="40">
						&nbsp;<strong>设备:</strong>&nbsp;
					</td>
					<td width="1">
						<select name="host_id" onChange="applyViewSNMPFilterChange(document.form_snmpcache)">
							<option value="-1"<?php if (get_request_var_request("host_id") == "-1") {?> selected<?php }?>>所有</option>
							<option value="0"<?php if (get_request_var_request("host_id") == "0") {?> selected<?php }?>>无</option>
							<?php
							if (get_request_var_request("snmp_query_id") == -1) {
								$hosts = db_fetch_assoc("SELECT DISTINCT
											host.id,
											host.description,
											host.hostname
											FROM (host_snmp_cache,snmp_query,host)
											WHERE host_snmp_cache.host_id=host.id
											AND host_snmp_cache.snmp_query_id=snmp_query.id
											ORDER by host.description");
							}else{
								$hosts = db_fetch_assoc("SELECT DISTINCT
											host.id,
											host.description,
											host.hostname
											FROM (host_snmp_cache,snmp_query,host)
											WHERE host_snmp_cache.host_id=host.id
											AND host_snmp_cache.snmp_query_id=snmp_query.id
											AND host_snmp_cache.snmp_query_id='" . get_request_var_request("snmp_query_id") . "'
											ORDER by host.description");
							}
							if (sizeof($hosts) > 0) {
							foreach ($hosts as $host) {
								print "<option value='" . $host["id"] . "'"; if (get_request_var_request("host_id") == $host["id"]) { print " selected"; } print ">" . $host["description"] . "</option>\n";
							}
							}
							?>
						</select>
					</td>
					<td nowrap style='white-space: nowrap;' width="65">
						&nbsp;<strong>查询名称:</strong>&nbsp;
					</td>
					<td width="1">
						<select name="snmp_query_id" onChange="applyViewSNMPFilterChange(document.form_snmpcache)">
							<option value="-1"<?php if (get_request_var_request("host_id") == "-1") {?> selected<?php }?>>所有</option>
							<?php
							if (get_request_var_request("host_id") == -1) {
								$snmp_queries = db_fetch_assoc("SELECT DISTINCT
											snmp_query.id,
											snmp_query.name
											FROM (host_snmp_cache,snmp_query,host)
											WHERE host_snmp_cache.host_id=host.id
											AND host_snmp_cache.snmp_query_id=snmp_query.id
											ORDER by snmp_query.name");
							}else{
								$snmp_queries = db_fetch_assoc("SELECT DISTINCT
											snmp_query.id,
											snmp_query.name
											FROM (host_snmp_cache,snmp_query,host)
											WHERE host_snmp_cache.host_id=host.id
											AND host_snmp_cache.host_id='" . get_request_var_request("host_id") . "'
											AND host_snmp_cache.snmp_query_id=snmp_query.id
											ORDER by snmp_query.name");
							}
							if (sizeof($snmp_queries) > 0) {
							foreach ($snmp_queries as $snmp_query) {
								print "<option value='" . $snmp_query["id"] . "'"; if (get_request_var_request("snmp_query_id") == $snmp_query["id"]) { print " selected"; } print ">" . $snmp_query["name"] . "</option>\n";
							}
							}
							?>
						</select>
					</td>
					<td nowrap style='white-space: nowrap;' width="40">
						&nbsp;<strong>搜索:</strong>&nbsp;
					</td>
					<td width="1">
						<input type="text" name="filter" size="20" value="<?php print get_request_var_request("filter");?>">
					</td>
					<td nowrap style='white-space: nowrap;'>
						&nbsp;<input type="image" src="images/button_go.gif" name="go" alt="确认" border="0" align="absmiddle">
						<input type="image" src="images/button_clear.gif" name="clear" alt="清除" border="0" align="absmiddle">
					</td>
				</tr>
			</table>
		</td>
		<input type='hidden' name='page' value='1'>
		<input type='hidden' name='action' value='view_snmp_cache'>
		</form>
	</tr>
	<?php

	html_end_box();

	$sql_where = "";

	/* filter by host */
	if (get_request_var_request("host_id") == "-1") {
		/* Show all items */
	}elseif (get_request_var_request("host_id") == "0") {
		$sql_where .= " AND host.id=0";
	}elseif (!empty($_REQUEST["host_id"])) {
		$sql_where .= " AND host.id=" . get_request_var_request("host_id");
	}

	/* filter by query name */
	if (get_request_var_request("snmp_query_id") == "-1") {
		/* Show all items */
	}elseif (!empty($_REQUEST["snmp_query_id"])) {
		$sql_where .= " AND host_snmp_cache.snmp_query_id=" . get_request_var_request("snmp_query_id");
	}

	/* filter by search string */
	if (get_request_var_request("filter") != "") {
		$sql_where .= " AND (host.description LIKE '%%" . get_request_var_request("filter") . "%%'
			OR snmp_query.name LIKE '%%" . iget_request_var_request("filter") . "%%'
			OR host_snmp_cache.field_name LIKE '%%" . get_request_var_request("filter") . "%%'
			OR host_snmp_cache.field_value LIKE '%%" . get_request_var_request("filter") . "%%'
			OR host_snmp_cache.oid LIKE '%%" . get_request_var_request("filter") . "%%')";
	}

	html_start_box("", "100%", $colors["header"], "3", "center", "");

	$total_rows = db_fetch_cell("SELECT
		COUNT(*)
		FROM (host_snmp_cache,snmp_query,host)
		WHERE host_snmp_cache.host_id=host.id
		AND host_snmp_cache.snmp_query_id=snmp_query.id
		$sql_where");

	$snmp_cache_sql = "SELECT
		host_snmp_cache.*,
		host.description,
		snmp_query.name
		FROM (host_snmp_cache,snmp_query,host)
		WHERE host_snmp_cache.host_id=host.id
		AND host_snmp_cache.snmp_query_id=snmp_query.id
		$sql_where
		LIMIT " . (read_config_option("num_rows_data_source")*(get_request_var_request("page")-1)) . "," . read_config_option("num_rows_data_source");

//	print $snmp_cache_sql;

	$snmp_cache = db_fetch_assoc($snmp_cache_sql);

	/* generate page list */
	$url_page_select = get_page_list(get_request_var_request("page"), MAX_DISPLAY_PAGES, read_config_option("num_rows_data_source"), $total_rows, "utilities.php?action=view_snmp_cache&host_id=" . get_request_var_request("host_id") . "&filter=" . get_request_var_request("filter"));

	$nav = "<tr bgcolor='#" . $colors["header"] . "'>
			<td colspan='7'>
				<table width='100%' cellspacing='0' cellpadding='0' border='0'>
					<tr>
						<td align='left' class='textHeaderDark'>
							<strong>&lt;&lt; "; if (get_request_var_request("page") > 1) { $nav .= "<a class='linkOverDark' href='utilities.php?action=view_snmp_cache&host_id=" . get_request_var_request("host_id") . "&filter=" . get_request_var_request("filter") . "&page=" . (get_request_var_request("page")-1) . "'>"; } $nav .= "上一页"; if (get_request_var_request("page") > 1) { $nav .= "</a>"; } $nav .= "</strong>
						</td>\n
						<td align='center' class='textHeaderDark'>
							显示行 " . ((read_config_option("num_rows_data_source")*(get_request_var_request("page")-1))+1) . " 至 " . ((($total_rows < read_config_option("num_rows_data_source")) || ($total_rows < (read_config_option("num_rows_data_source")*get_request_var_request("page")))) ? $total_rows : (read_config_option("num_rows_data_source")*get_request_var_request("page"))) . " 共 $total_rows [$url_page_select]
						</td>\n
						<td align='right' class='textHeaderDark'>
							<strong>"; if ((get_request_var_request("page") * read_config_option("num_rows_data_source")) < $total_rows) { $nav .= "<a class='linkOverDark' href='utilities.php?action=view_snmp_cache&host_id=" . get_request_var_request("host_id") . "&filter=" . get_request_var_request("filter") . "&page=" . (get_request_var_request("page")+1) . "'>"; } $nav .= "下一页"; if ((get_request_var_request("page") * read_config_option("num_rows_data_source")) < $total_rows) { $nav .= "</a>"; } $nav .= " &gt;&gt;</strong>
						</td>\n
					</tr>
				</table>
			</td>
		</tr>\n";

	print $nav;

	html_header(array("明细"));

	if (empty($_REQUEST["filter"])|| !isset($_REQUEST["filter"])) $_REQUEST["filter"]=".*";
	$i = 0;
	if (sizeof($snmp_cache) > 0) {
	foreach ($snmp_cache as $item) {
		form_alternate_row_color($colors["form_alternate1"],$colors["form_alternate2"],$i);
		?>
		<td>
			设备: <?php print (strlen(get_request_var_request("filter")) ? (eregi_replace("(" . preg_quote(get_request_var_request("filter")) . ")", "<span style='background-color: #F8D93D;'>\\1</span>", $item["description"])) : $item["description"]);?>
			, SNMP查询: <?php print (strlen(get_request_var_request("filter")) ? (eregi_replace("(" . preg_quote(get_request_var_request("filter")) . ")", "<span style='background-color: #F8D93D;'>\\1</span>", $item["name"])) : $item["name"]);?>
		</td>
		</tr>
		<?php
		form_alternate_row_color($colors["form_alternate1"],$colors["form_alternate2"],$i);
		?>
		<td>
			索引: <?php print $item["snmp_index"];?>
			, 域名称: <?php print (strlen(get_request_var_request("filter")) ? (eregi_replace("(" . preg_quote(get_request_var_request("filter")) . ")", "<span style='background-color: #F8D93D;'>\\1</span>", $item["field_name"])) : $item["field_name"]);?>
			, 域值: <?php print (strlen(get_request_var_request("filter")) ? (eregi_replace("(" . preg_quote(get_request_var_request("filter")) . ")", "<span style='background-color: #F8D93D;'>\\1</span>", $item["field_value"])) : $item["field_value"]);?>
		</td>
		</tr>
		<?php
		form_alternate_row_color($colors["form_alternate1"],$colors["form_alternate2"],$i); $i++;
		?>
		<td>
			OID: <?php print (strlen(get_request_var_request("filter")) ? (eregi_replace("(" . preg_quote(get_request_var_request("filter")) . ")", "<span style='background-color: #F8D93D;'>\\1</span>", $item["oid"])) : $item["oid"]);?>
		</td>
		</tr>
		<?php
	}
	}

	html_end_box();
}

function utilities_view_poller_cache() {
	global $colors, $poller_actions;

	define("MAX_DISPLAY_PAGES", 21);

	/* ================= input validation ================= */
	input_validate_input_number(get_request_var_request("host_id"));
	input_validate_input_number(get_request_var_request("page"));
	input_validate_input_number(get_request_var_request("poller_action"));
	/* ==================================================== */

	/* clean up search filter */
	if (isset($_REQUEST["filter"])) {
		$_REQUEST["filter"] = sanitize_search_string(get_request_var("filter"));
	}

	/* clean up sort_column */
	if (isset($_REQUEST["sort_column"])) {
		$_REQUEST["sort_column"] = sanitize_search_string(get_request_var("sort_column"));
	}

	/* clean up sort direction */
	if (isset($_REQUEST["sort_direction"])) {
		$_REQUEST["sort_direction"] = sanitize_search_string(get_request_var("sort_direction"));
	}

	/* if the user pushed the 'clear' button */
	if (isset($_REQUEST["clear_x"])) {
		kill_session_var("sess_poller_current_page");
		kill_session_var("sess_poller_host_id");
		kill_session_var("sess_poller_poller_action");
		kill_session_var("sess_poller_filter");

		unset($_REQUEST["page"]);
		unset($_REQUEST["filter"]);
		unset($_REQUEST["host_id"]);
		unset($_REQUEST["poller_action"]);
	}

	if ((!empty($_SESSION["sess_poller_action"])) && (!empty($_REQUEST["poller_action"]))) {
		if ($_SESSION["sess_poller_poller_action"] != $_REQUEST["poller_action"]) {
			$_REQUEST["page"] = 1;
		}
	}

	/* remember these search fields in session vars so we don't have to keep passing them around */
	load_current_session_value("page", "sess_poller_current_page", "1");
	load_current_session_value("host_id", "sess_poller_host_id", "-1");
	load_current_session_value("poller_action", "sess_poller_poller_action", "-1");
	load_current_session_value("filter", "sess_poller_filter", "");
	load_current_session_value("sort_column", "sess_poller_sort_column", "data_template_data.name_cache");
	load_current_session_value("sort_direction", "sess_poller_sort_direction", "ASC");

	$_REQUEST['page_referrer'] = 'view_poller_cache';
	load_current_session_value('page_referrer', 'page_referrer', 'view_poller_cache');

	?>
	<script type="text/javascript">
	<!--

	function applyPItemFilterChange(objForm) {
		strURL = '?poller_action=' + objForm.poller_action.value;
		strURL = strURL + '&host_id=' + objForm.host_id.value;
		strURL = strURL + '&filter=' + objForm.filter.value;
		strURL = strURL + '&action=view_poller_cache';
		document.location = strURL;
	}

	-->
	</script>
	<?php

	html_start_box("<strong>轮询器缓存项目</strong>", "100%", $colors["header"], "3", "center", "");

	?>
	<tr bgcolor="<?php print $colors["panel"];?>">
		<form name="form_pollercache">
		<td>
			<table cellpadding="0" cellspacing="0">
				<tr>
					<td nowrap style='white-space: nowrap;' width="40">
						&nbsp;<strong>设备:</strong>&nbsp;
					</td>
					<td width="1">
						<select name="host_id" onChange="applyPItemFilterChange(document.form_pollercache)">
							<option value="-1"<?php if (get_request_var_request("host_id") == "-1") {?> selected<?php }?>>所有</option>
							<option value="0"<?php if (get_request_var_request("host_id") == "0") {?> selected<?php }?>>无</option>
							<?php
							$hosts = db_fetch_assoc("select id,description,hostname from host order by description");

							if (sizeof($hosts) > 0) {
							foreach ($hosts as $host) {
								print "<option value='" . $host["id"] . "'"; if (get_request_var_request("host_id") == $host["id"]) { print " selected"; } print ">" . $host["description"] . "</option>\n";
							}
							}
							?>
						</select>
					</td>
					<td nowrap style='white-space: nowrap;' width="40">
						&nbsp;<strong>操作:</strong>&nbsp;
					</td>
					<td width="1">
						<select name="poller_action" onChange="applyPItemFilterChange(document.form_pollercache)">
							<option value="-1"<?php if (get_request_var_request("poller_action") == '-1') {?> selected<?php }?>>所有</option>
							<option value="0"<?php if (get_request_var_request("poller_action") == '0') {?> selected<?php }?>>SNMP</option>
							<option value="1"<?php if (get_request_var_request("poller_action") == '1') {?> selected<?php }?>>脚本</option>
							<option value="2"<?php if (get_request_var_request("poller_action") == '2') {?> selected<?php }?>>脚本服务程序</option>
						</select>
					</td>
					<td nowrap style='white-space: nowrap;' width="40">
						&nbsp;<strong>搜索:</strong>&nbsp;
					</td>
					<td width="1">
						<input type="text" name="filter" size="40" value="<?php print get_request_var_request("filter");?>">
					</td>
					<td nowrap style='white-space: nowrap;'>
						&nbsp;<input type="image" src="images/button_go.gif" name="go" alt="确认" border="0" align="absmiddle">
						<input type="image" src="images/button_clear.gif" name="clear" alt="清除" border="0" align="absmiddle">
					</td>
				</tr>
			</table>
		</td>
		<input type='hidden' name='page' value='1'>
		<input type='hidden' name='action' value='view_poller_cache'>
		</form>
	</tr>
	<?php

	html_end_box();

	/* form the 'where' clause for our main sql query */
	$sql_where = "WHERE poller_item.local_data_id=data_template_data.local_data_id";

	if (get_request_var_request("poller_action") != "-1") {
		$sql_where .= " AND poller_item.action='" . get_request_var_request("poller_action") . "'";
	}

	if (get_request_var_request("host_id") == "-1") {
		/* Show all items */
	}elseif (get_request_var_request("host_id") == "0") {
		$sql_where .= " AND poller_item.host_id=0";
	}elseif (!empty($_REQUEST["host_id"])) {
		$sql_where .= " AND poller_item.host_id=" . get_request_var_request("host_id");
	}

	if (strlen(get_request_var_request("filter"))) {
		$sql_where .= " AND (data_template_data.name_cache LIKE '%%" . get_request_var_request("filter") . "%%'
			OR host.description LIKE '%%" . get_request_var_request("filter") . "%%'
			OR poller_item.arg1 LIKE '%%" . get_request_var_request("filter") . "%%'
			OR poller_item.hostname LIKE '%%" . get_request_var_request("filter") . "%%'
			OR poller_item.rrd_path  LIKE '%%" . get_request_var_request("filter") . "%%')";
	}

	html_start_box("", "100%", $colors["header"], "3", "center", "");

	$total_rows = db_fetch_cell("SELECT
		COUNT(*)
		FROM data_template_data
		RIGHT JOIN (poller_item
		LEFT JOIN host
		ON poller_item.host_id=host.id)
		ON data_template_data.local_data_id=poller_item.local_data_id
		$sql_where");

	$poller_sql = "SELECT
		poller_item.*,
		data_template_data.name_cache,
		host.description
		FROM data_template_data
		RIGHT JOIN (poller_item
		LEFT JOIN host
		ON poller_item.host_id=host.id)
		ON data_template_data.local_data_id=poller_item.local_data_id
		$sql_where
		ORDER BY " . get_request_var_request("sort_column") . " " . get_request_var_request("sort_direction") . ", action ASC
		LIMIT " . (read_config_option("num_rows_data_source")*(get_request_var_request("page")-1)) . "," . read_config_option("num_rows_data_source");

//	print $poller_sql;

	$poller_cache = db_fetch_assoc($poller_sql);

	/* generate page list */
	$url_page_select = get_page_list(get_request_var_request("page"), MAX_DISPLAY_PAGES, read_config_option("num_rows_data_source"), $total_rows, "utilities.php?action=view_poller_cache&host_id=" . get_request_var_request("host_id") . "&poller_action=" . get_request_var_request("poller_action"));

	$nav = "<tr bgcolor='#" . $colors["header"] . "'>
			<td colspan='7'>
				<table width='100%' cellspacing='0' cellpadding='0' border='0'>
					<tr>
						<td align='left' class='textHeaderDark'>
							<strong>&lt;&lt; "; if (get_request_var_request("page") > 1) { $nav .= "<a class='linkOverDark' href='utilities.php?action=view_poller_cache&host_id=" . get_request_var_request("host_id") . "&poller_action=" . get_request_var_request("poller_action") . "&page=" . (get_request_var_request("page")-1) . "'>"; } $nav .= "上一页"; if (get_request_var_request("page") > 1) { $nav .= "</a>"; } $nav .= "</strong>
						</td>\n
						<td align='center' class='textHeaderDark'>
							显示行 " . ((read_config_option("num_rows_data_source")*(get_request_var_request("page")-1))+1) . " 至 " . ((($total_rows < read_config_option("num_rows_data_source")) || ($total_rows < (read_config_option("num_rows_data_source")*get_request_var_request("page")))) ? $total_rows : (read_config_option("num_rows_data_source")*get_request_var_request("page"))) . " 共 $total_rows [$url_page_select]
						</td>\n
						<td align='right' class='textHeaderDark'>
							<strong>"; if ((get_request_var_request("page") * read_config_option("num_rows_data_source")) < $total_rows) { $nav .= "<a class='linkOverDark' href='utilities.php?action=view_poller_cache&host_id=" . get_request_var_request("host_id") . "&poller_action=" . get_request_var_request("poller_action") . "&page=" . (get_request_var_request("page")+1) . "'>"; } $nav .= "下一页"; if ((get_request_var_request("page") * read_config_option("num_rows_data_source")) < $total_rows) { $nav .= "</a>"; } $nav .= " &gt;&gt;</strong>
						</td>\n
					</tr>
				</table>
			</td>
		</tr>\n";

	print $nav;

	$display_text = array(
		"data_template_data.name_cache" => array("数据源名称", "ASC"),
		"" => array("明细", "ASC"));

	html_header_sort($display_text, get_request_var_request("sort_column"), get_request_var_request("sort_direction"));

	if (empty($_REQUEST["filter"])|| !isset($_REQUEST["filter"])) $_REQUEST["filter"]=".*";
	$i = 0;
	if (sizeof($poller_cache) > 0) {
	foreach ($poller_cache as $item) {
		form_alternate_row_color($colors["form_alternate1"],$colors["form_alternate2"],$i);
			?>
			<td width="375">
				<a class="linkEditMain" href="data_sources.php?action=ds_edit&id=<?php print $item["local_data_id"];?>"><?php print eregi_replace("(" . preg_quote(get_request_var_request("filter")) . ")", "<span style='background-color: #F8D93D;'>\\1</span>", $item["name_cache"]);?></a>
			</td>

			<td>
			<?php
			if ($item["action"] == 0) {
				if ($item["snmp_version"] != 3) {
					$details =
						"SNMP版本: " . $item["snmp_version"] . ", " .
						"连接字串: " . $item["snmp_community"] . ", " .
						"OID: " . (strlen(get_request_var_request("filter")) ? (eregi_replace("(" . preg_quote(get_request_var_request("filter")) . ")", "<span style='background-color: #F8D93D;'>\\1</span>", $item["arg1"])) : $item["arg1"]);
				}else{
					$details =
						"SNMP版本: " . $item["snmp_version"] . ", " .
						"用户: " . $item["snmp_username"] . ", OID: " . $item["arg1"];
				}
			}elseif ($item["action"] == 1) {
					$details = "脚本: " . (strlen(get_request_var_request("filter")) ? (eregi_replace("(" . preg_quote(get_request_var_request("filter")) . ")", "<span style='background-color: #F8D93D;'>\\1</span>", $item["arg1"])) : $item["arg1"]);
			}else{
					$details = "服本服务程序: " . (strlen(get_request_var_request("filter")) ? (eregi_replace("(" . preg_quote(get_request_var_request("filter")) . ")", "<span style='background-color: #F8D93D;'>\\1</span>", $item["arg1"])) : $item["arg1"]);
			}

			print $details;
			?>
			</td>
		</tr>
		<?php

		form_alternate_row_color($colors["form_alternate1"],$colors["form_alternate2"],$i);
		?>
			<td>
			</td>
			<td>
				RRD: <?php print $item["rrd_path"];?>
			</td>
		</tr>
		<?php
		$i++;
	}
	}

	html_end_box();
}

function utilities() {
	global $colors;

	html_start_box("<strong>Cacti系统工具</strong>", "100%", $colors["header"], "3", "center", "");

	?>
	<colgroup span="3">
		<col valign="top" width="20"></col>
		<col valign="top" width="10"></col>
	</colgroup>

	<?php html_header(array("技术支持"), 2); ?>
	<tr bgcolor="#<?php print $colors["form_alternate1"];?>">
		<td class="textArea">
			<p><a href='utilities.php?action=view_tech'>技术支持</a></p>
		</td>
		<td class="textArea">
			<p>Cacti技术支持页面.  供开发及技术支持人员使用以帮助确定Cacti中的问题.  包含普通配置上问题的检测.</p>
		</td>
	</tr>

	<?php html_header(array("日志管理"), 2);?>

	<tr bgcolor="#<?php print $colors["form_alternate1"];?>">
		<td class="textArea">
			<p><a href='utilities.php?action=view_logfile'>查看Cacti日志文件</a></p>
		</td>
		<td class="textArea">
			<p>Cacti的日志文件保存统计,错误和其他依赖于系统设置的信息.此信息可用来判断轮询器和应用问题.</p>
		</td>
	</tr>
	<tr bgcolor="#<?php print $colors["form_alternate1"];?>">
		<td class="textArea">
			<p><a href='utilities.php?action=view_user_log'>查看用户日志</a></p>
		</td>
		<td class="textArea">
			<p>允许管理员浏览用户日志. 管理员也能过滤和导出日志.</p>
		</td>
	</tr>

	<?php html_header(array("轮询器缓存管理"), 2); ?>

	<tr bgcolor="#<?php print $colors["form_alternate1"];?>">
		<td class="textArea">
			<p><a href='utilities.php?action=view_poller_cache'>查看轮询器缓存</a></p>
		</td>
		<td class="textArea">
			<p>在轮询器每次运行时,数据被传递给轮询器. 数据依次运行/解释,结果流入图像的rrd文件中或用于显示的数据库中.</p>
		</td>
	</tr>
	<tr bgcolor="#<?php print $colors["form_alternate2"];?>">
		<td class="textArea">
			<p><a href='utilities.php?action=view_snmp_cache'>查看SNMP缓存</a></p>
		</td>
		<td class="textArea">
			<p>SNMP缓存保存SNMP查询所收集的信息. 当从启用SNMP的设备中获取信息时,Cacti使用它来求出用来使用的OID.</p>
		</td>
	</tr>
	<tr bgcolor="#<?php print $colors["form_alternate1"];?>">
		<td class="textArea">
			<p><a href='utilities.php?action=clear_poller_cache'>重建轮询器缓存</a></p>
		</td>
		<td class="textArea">
			<p>如果点选此项,轮询器缓存将被清除并重新生成. 有时设备/数据源的数据与缓存不同步,在这种情况下清除并重新开始是有意义的.</p>
		</td>
	</tr>

	<?php

	html_end_box();
}

?>


