#ifndef PHP_QDBM_H
#define PHP_QDBM_H

#if DBA_QDBM

#include "php_dba.h"

DBA_FUNCS(qdbm);

#endif

#endif
